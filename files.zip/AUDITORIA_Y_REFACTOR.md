# IN CRYPTA — Auditoría y refactor (estado verificado)

Archivo entregado: IN_CRYPTA_NATIVO_REFACTOR.json (reemplaza a IN_CRYPTA_NATIVO_PARCHE.json, que queda superseded).
Base: IN_CRYPTA_NATIVO.json (GDevelop 5.6.285, 15 escenas).

**Estado:** NO verificado en GDevelop ni en build HTML5. Antes de usarlo: abrir, compilar, Preview y exportar.

## Verificado por análisis del JSON
- Cero eventos JavaScript (JsCode) en todo el proyecto.
- Los 199 recursos declarados existen en assets/.
- No hay objetos referenciados en eventos fuera de su escena (salvo expresiones, sin fallo).
- Las plataformas Solido coinciden con el arte de fondo (comprobado visualmente en Tutorial y Nivel 1).
- No hay costuras entre bloques de plataforma (rejilla de 32 px exacta).
- Controles por defecto de PlatformerObject desactivados (ignoreDefaultControls = true).
- Tiempos de coyote (0,10 s), buffer (0,12 s) y dash (0,20 s / recarga 0,60 s) se decrementan en la hoja compartida.

## Cambios aplicados
1. Nivel 2: farol flotante (3910,450) movido a (3844,450), sobre la plataforma.
2. Título: teclas 1–3 reasignadas a Tutorial / Nivel 1 / Nivel 2 (antes Nivel 1 / Nivel 2 / Nivel 3, sin coincidir con el menú). Tecla 4 agregada → Salas.
3. Título: pie de atajos y descripción del Nivel 2 corregidos (la pala no está disponible al empezar ese nivel).
4. Refactor de duplicación: 5 tramos de eventos idénticos (102 bloques, copiados en 2 a 10 escenas) movidos a hojas externas IN_CRYPTA_COMUN_01 a 05 y reemplazados por eventos Link. Verificado: expandiendo los Link, las 15 escenas son idénticas al original.

## Duplicación pendiente (requiere IDE)
- 717 copias idénticas de eventos en total, pero solo 5 tramos consecutivos son reemplazables sin cambiar el orden de ejecución. El resto está intercalado con lógica específica de cada escena.
- El ataque (J y clic) está repetido en 10 escenas con pequeñas variaciones. Unificarlo en una hoja compartida requiere revisar cada escena en el editor.

## Decisiones pendientes
- Salto en Nivel 2 y Nivel 3: el primer hueco (224 px, subida de 32 px en Nivel 2) no se cruza con salto corto. Hay que mantener Espacio o usar dash en el aire. Opciones: enseñar el salto mantenido en el Tutorial, agregar aviso antes del hueco, o ajustar la física (afecta a todos los niveles).
- Valores escritos en eventos y no documentados: JumpSpeed 360 (rebote tras pisotón, con pala) y MaxSpeed 295 (al saltar desde el dash).
- Render: el proyecto usa scaleMode linear. Para pixel art conviene comparar con nearest en una captura real antes de decidir.
- Checkpoint del dash en Nivel 1: no se encontró error objetivo en su posición. Falta el dato de qué farol se ve mal.
- Plataformas móviles (Nivel 2 y 3) se mueven por eventos; no se pudo simular su efecto sobre el alcance de los saltos.

## Extensiones de la tienda
Instalación: Project Manager → "Create or search for new extensions" (o el botón + de la sección Extensions) → buscar → "Install in project". No se instalan escribiendo JSON.

- Advanced platformer movements (comunidad): air jump, wall jump/slide, coyote time (ledge tolerance), horizontal dash (cooldown por defecto 0,25 s, deceleración 3000), dive dash.
  - No incluye jump buffer: el buffer se mantiene nativo.
  - Reemplaza el dash y el coyote nativos, con propiedades distintas. Migrar exige reconfigurar y reescribir eventos. Probarla en una copia, sin mezclar ambas implementaciones.
- Checkpoints ("Respawn objects at checkpoints"): opcional, el sistema de faroles actual funciona.
- Platformer character animator: opcional, las animaciones están hechas a mano.
