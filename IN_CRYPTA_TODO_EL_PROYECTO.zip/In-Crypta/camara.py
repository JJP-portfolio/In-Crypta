# ============================================================
# camara.py — Cámara con seguimiento y sacudida
# ============================================================
# La cámara guarda cuánto hay que restar a las coordenadas del mundo
# para dibujarlas en pantalla. El HUD NO usa la cámara.
# ============================================================

import random

import pygame

from config import (
    ALTO,
    ANCHO,
    CAMARA_SUAVIZADO,
    SACUDIDA_DURACION,
    SACUDIDA_FUERZA,
    VIRTUAL_ALTO,
    VIRTUAL_ANCHO,
)


# --- Clase Camara --- #
class Camara:
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.sacudida_tiempo = 0.0
        self.sacudida_fuerza = 0.0
        self.trauma = 0.0
        self.permitir_sacudida = True

    # --- Función actualizar --- #
    def actualizar(self, jugador, nivel, dt):
        objetivo_x = jugador.rect.centerx - VIRTUAL_ANCHO // 2
        objetivo_y = jugador.rect.centery - VIRTUAL_ALTO // 2

        factor = min(1.0, CAMARA_SUAVIZADO * dt)
        self.x += (objetivo_x - self.x) * factor
        self.y += (objetivo_y - self.y) * factor

        max_x = max(0, nivel.ancho - VIRTUAL_ANCHO)
        max_y = max(0, nivel.alto - VIRTUAL_ALTO)
        self.x = max(0.0, min(self.x, max_x))
        self.y = max(0.0, min(self.y, max_y))

        if nivel.ancho < VIRTUAL_ANCHO:
            self.x = (nivel.ancho - VIRTUAL_ANCHO) / 2
        # Si el nivel es más bajo que la altura de la vista, anclar el suelo abajo
        # para que no haya vacío negro debajo del piso y se aprecie el fondo gótico
        if nivel.alto <= VIRTUAL_ALTO:
            self.y = float(nivel.alto - VIRTUAL_ALTO)

        self.actualizar_sacudida(dt)

    # --- Función sacudir --- #
    def sacudir(self, fuerza=SACUDIDA_FUERZA, duracion=SACUDIDA_DURACION):
        if not self.permitir_sacudida:
            self.offset_x = 0.0
            self.offset_y = 0.0
            self.trauma = 0.0
            return
        self.sacudida_tiempo = max(self.sacudida_tiempo, duracion)
        self.sacudida_fuerza = max(self.sacudida_fuerza, fuerza)
        # Trauma polinómico (Squirrel Eiserloh, GDC 2016)
        incremento = min(1.0, fuerza / 14.0)
        self.trauma = min(1.0, self.trauma + incremento)

    # --- Función actualizar_sacudida --- #
    def actualizar_sacudida(self, dt):
        if not self.permitir_sacudida or (self.sacudida_tiempo <= 0 and self.trauma <= 0):
            self.offset_x = 0.0
            self.offset_y = 0.0
            self.trauma = 0.0
            return

        self.sacudida_tiempo = max(0.0, self.sacudida_tiempo - dt)
        tasa_decaimiento = 1.0 / max(0.01, SACUDIDA_DURACION)
        self.trauma = max(0.0, self.trauma - tasa_decaimiento * dt)

        # Shake polinómico: trauma al cuadrado (T^2) para mayor pegada y caída orgánica
        shake = self.trauma * self.trauma
        if shake > 0:
            intensidad = self.sacudida_fuerza * shake
            self.offset_x = random.uniform(-intensidad, intensidad)
            self.offset_y = random.uniform(-intensidad, intensidad)
        else:
            self.offset_x = 0.0
            self.offset_y = 0.0

    # --- Función aplicar_x / aplicar_y --- #
    def aplicar_x(self, x):
        return x - self.x + self.offset_x

    def aplicar_y(self, y):
        return y - self.y + self.offset_y

    # --- Función aplicar_rect --- #
    def aplicar_rect(self, rect):
        return pygame.Rect(
            round(rect.x - self.x + self.offset_x),
            round(rect.y - self.y + self.offset_y),
            rect.width,
            rect.height,
        )

    # --- Función is_on_screen --- #
    def is_on_screen(self, rect, margen=64):
        return (
            rect.right >= self.x - margen
            and rect.left <= self.x + VIRTUAL_ANCHO + margen
            and rect.bottom >= self.y - margen
            and rect.top <= self.y + VIRTUAL_ALTO + margen
        )
