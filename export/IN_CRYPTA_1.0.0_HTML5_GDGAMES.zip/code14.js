gdjs.Sala_32_6Code = {};
gdjs.Sala_32_6Code.localVariables = [];
gdjs.Sala_32_6Code.idToCallbackMap = new Map();
gdjs.Sala_32_6Code.GDJugadorObjects1_1final = [];

gdjs.Sala_32_6Code.GDFondoObjects1= [];
gdjs.Sala_32_6Code.GDFondoObjects2= [];
gdjs.Sala_32_6Code.GDFondoObjects3= [];
gdjs.Sala_32_6Code.GDSolidoObjects1= [];
gdjs.Sala_32_6Code.GDSolidoObjects2= [];
gdjs.Sala_32_6Code.GDSolidoObjects3= [];
gdjs.Sala_32_6Code.GDJugadorObjects1= [];
gdjs.Sala_32_6Code.GDJugadorObjects2= [];
gdjs.Sala_32_6Code.GDJugadorObjects3= [];
gdjs.Sala_32_6Code.GDPuertaObjects1= [];
gdjs.Sala_32_6Code.GDPuertaObjects2= [];
gdjs.Sala_32_6Code.GDPuertaObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595DashObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595DashObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595DashObjects3= [];
gdjs.Sala_32_6Code.GDJefeObjects1= [];
gdjs.Sala_32_6Code.GDJefeObjects2= [];
gdjs.Sala_32_6Code.GDJefeObjects3= [];
gdjs.Sala_32_6Code.GDOndaIzqObjects1= [];
gdjs.Sala_32_6Code.GDOndaIzqObjects2= [];
gdjs.Sala_32_6Code.GDOndaIzqObjects3= [];
gdjs.Sala_32_6Code.GDOndaDerObjects1= [];
gdjs.Sala_32_6Code.GDOndaDerObjects2= [];
gdjs.Sala_32_6Code.GDOndaDerObjects3= [];
gdjs.Sala_32_6Code.GDGolpePalaObjects1= [];
gdjs.Sala_32_6Code.GDGolpePalaObjects2= [];
gdjs.Sala_32_6Code.GDGolpePalaObjects3= [];
gdjs.Sala_32_6Code.GDAlmaObjects1= [];
gdjs.Sala_32_6Code.GDAlmaObjects2= [];
gdjs.Sala_32_6Code.GDAlmaObjects3= [];
gdjs.Sala_32_6Code.GDMiniJefeObjects1= [];
gdjs.Sala_32_6Code.GDMiniJefeObjects2= [];
gdjs.Sala_32_6Code.GDMiniJefeObjects3= [];
gdjs.Sala_32_6Code.GDPowerUpRangoObjects1= [];
gdjs.Sala_32_6Code.GDPowerUpRangoObjects2= [];
gdjs.Sala_32_6Code.GDPowerUpRangoObjects3= [];
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1= [];
gdjs.Sala_32_6Code.GDFarolCheckpointObjects2= [];
gdjs.Sala_32_6Code.GDFarolCheckpointObjects3= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects2= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects3= [];
gdjs.Sala_32_6Code.GDJefeObjects1= [];
gdjs.Sala_32_6Code.GDJefeObjects2= [];
gdjs.Sala_32_6Code.GDJefeObjects3= [];
gdjs.Sala_32_6Code.GDPalaRecogibleObjects1= [];
gdjs.Sala_32_6Code.GDPalaRecogibleObjects2= [];
gdjs.Sala_32_6Code.GDPalaRecogibleObjects3= [];
gdjs.Sala_32_6Code.GDFondoTituloObjects1= [];
gdjs.Sala_32_6Code.GDFondoTituloObjects2= [];
gdjs.Sala_32_6Code.GDFondoTituloObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects3= [];
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects1= [];
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects2= [];
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects3= [];
gdjs.Sala_32_6Code.GDFondoPausaObjects1= [];
gdjs.Sala_32_6Code.GDFondoPausaObjects2= [];
gdjs.Sala_32_6Code.GDFondoPausaObjects3= [];
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects1= [];
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects2= [];
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects3= [];
gdjs.Sala_32_6Code.GDPausa_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDPausa_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDPausa_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects1= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects2= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects3= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects1= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects2= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects3= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects1= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects2= [];
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects3= [];
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects1= [];
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects2= [];
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects3= [];
gdjs.Sala_32_6Code.GDFondoDerrotaObjects1= [];
gdjs.Sala_32_6Code.GDFondoDerrotaObjects2= [];
gdjs.Sala_32_6Code.GDFondoDerrotaObjects3= [];
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects1= [];
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects2= [];
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects3= [];
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects1= [];
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects2= [];
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects3= [];
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects1= [];
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects2= [];
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects3= [];
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects1= [];
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects2= [];
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects3= [];
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects1= [];
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects2= [];
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects3= [];
gdjs.Sala_32_6Code.GDFondoVictoriaObjects1= [];
gdjs.Sala_32_6Code.GDFondoVictoriaObjects2= [];
gdjs.Sala_32_6Code.GDFondoVictoriaObjects3= [];
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects1= [];
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects2= [];
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects3= [];
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects1= [];
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects2= [];
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects3= [];
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects1= [];
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects2= [];
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects3= [];
gdjs.Sala_32_6Code.GDFondoSalasObjects1= [];
gdjs.Sala_32_6Code.GDFondoSalasObjects2= [];
gdjs.Sala_32_6Code.GDFondoSalasObjects3= [];
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects1= [];
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects2= [];
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects3= [];
gdjs.Sala_32_6Code.GDSalas_9595SubObjects1= [];
gdjs.Sala_32_6Code.GDSalas_9595SubObjects2= [];
gdjs.Sala_32_6Code.GDSalas_9595SubObjects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects1= [];
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects2= [];
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects3= [];
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects1= [];
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects2= [];
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects3= [];
gdjs.Sala_32_6Code.GDFondoObjects1= [];
gdjs.Sala_32_6Code.GDFondoObjects2= [];
gdjs.Sala_32_6Code.GDFondoObjects3= [];
gdjs.Sala_32_6Code.GDSolidoObjects1= [];
gdjs.Sala_32_6Code.GDSolidoObjects2= [];
gdjs.Sala_32_6Code.GDSolidoObjects3= [];
gdjs.Sala_32_6Code.GDJugadorObjects1= [];
gdjs.Sala_32_6Code.GDJugadorObjects2= [];
gdjs.Sala_32_6Code.GDJugadorObjects3= [];
gdjs.Sala_32_6Code.GDPuertaObjects1= [];
gdjs.Sala_32_6Code.GDPuertaObjects2= [];
gdjs.Sala_32_6Code.GDPuertaObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects3= [];
gdjs.Sala_32_6Code.GDHUD_9595DashObjects1= [];
gdjs.Sala_32_6Code.GDHUD_9595DashObjects2= [];
gdjs.Sala_32_6Code.GDHUD_9595DashObjects3= [];
gdjs.Sala_32_6Code.GDJefeObjects1= [];
gdjs.Sala_32_6Code.GDJefeObjects2= [];
gdjs.Sala_32_6Code.GDJefeObjects3= [];
gdjs.Sala_32_6Code.GDOndaIzqObjects1= [];
gdjs.Sala_32_6Code.GDOndaIzqObjects2= [];
gdjs.Sala_32_6Code.GDOndaIzqObjects3= [];
gdjs.Sala_32_6Code.GDOndaDerObjects1= [];
gdjs.Sala_32_6Code.GDOndaDerObjects2= [];
gdjs.Sala_32_6Code.GDOndaDerObjects3= [];
gdjs.Sala_32_6Code.GDGolpePalaObjects1= [];
gdjs.Sala_32_6Code.GDGolpePalaObjects2= [];
gdjs.Sala_32_6Code.GDGolpePalaObjects3= [];
gdjs.Sala_32_6Code.GDAlmaObjects1= [];
gdjs.Sala_32_6Code.GDAlmaObjects2= [];
gdjs.Sala_32_6Code.GDAlmaObjects3= [];
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1= [];
gdjs.Sala_32_6Code.GDFarolCheckpointObjects2= [];
gdjs.Sala_32_6Code.GDFarolCheckpointObjects3= [];
gdjs.Sala_32_6Code.GDPalaRecogibleObjects1= [];
gdjs.Sala_32_6Code.GDPalaRecogibleObjects2= [];
gdjs.Sala_32_6Code.GDPalaRecogibleObjects3= [];
gdjs.Sala_32_6Code.GDEnemyObjects1= [];
gdjs.Sala_32_6Code.GDEnemyObjects2= [];
gdjs.Sala_32_6Code.GDEnemyObjects3= [];
gdjs.Sala_32_6Code.GDPowerUpDashObjects1= [];
gdjs.Sala_32_6Code.GDPowerUpDashObjects2= [];
gdjs.Sala_32_6Code.GDPowerUpDashObjects3= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects2= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects3= [];
gdjs.Sala_32_6Code.GDEnemyMeleeObjects1= [];
gdjs.Sala_32_6Code.GDEnemyMeleeObjects2= [];
gdjs.Sala_32_6Code.GDEnemyMeleeObjects3= [];
gdjs.Sala_32_6Code.GDPinchosObjects1= [];
gdjs.Sala_32_6Code.GDPinchosObjects2= [];
gdjs.Sala_32_6Code.GDPinchosObjects3= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects1= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects2= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects3= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects1= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects2= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects3= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects1= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects2= [];
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects3= [];
gdjs.Sala_32_6Code.GDMiniJefeObjects1= [];
gdjs.Sala_32_6Code.GDMiniJefeObjects2= [];
gdjs.Sala_32_6Code.GDMiniJefeObjects3= [];
gdjs.Sala_32_6Code.GDPowerUpRangoObjects1= [];
gdjs.Sala_32_6Code.GDPowerUpRangoObjects2= [];
gdjs.Sala_32_6Code.GDPowerUpRangoObjects3= [];


gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects2Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects2});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects1});
gdjs.Sala_32_6Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects2.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects2[k] = gdjs.Sala_32_6Code.GDJugadorObjects2[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects2 */
gdjs.Sala_32_6Code.GDGolpePalaObjects2.length = 0;

{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].setAnimation(2);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects2Objects, (( gdjs.Sala_32_6Code.GDJugadorObjects2.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJugadorObjects2[0].getPointX("")) + 24, (( gdjs.Sala_32_6Code.GDJugadorObjects2.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJugadorObjects2[0].getPointY("")) + 2, "");
}
}

}


{

/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = 0;

{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(5);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects, (( gdjs.Sala_32_6Code.GDJugadorObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJugadorObjects1[0].getPointX("")) - 24, (( gdjs.Sala_32_6Code.GDJugadorObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJugadorObjects1[0].getPointY("")) + 2, "");
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].setAnimation(3);
}
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDAlmaObjects1Objects = Hashtable.newFrom({"Alma": gdjs.Sala_32_6Code.GDAlmaObjects1});
gdjs.Sala_32_6Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() < 5);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Vida", false, 100, 1);
}
}

}


};gdjs.Sala_32_6Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() > 6);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(6);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma1", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 2);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma2", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 3);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma3", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 4);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma4", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 5);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma5", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 6);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma6", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() >= 10);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Sala_32_6Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPalaRecogibleObjects1Objects = Hashtable.newFrom({"PalaRecogible": gdjs.Sala_32_6Code.GDPalaRecogibleObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPowerUpRangoObjects1Objects = Hashtable.newFrom({"PowerUpRango": gdjs.Sala_32_6Code.GDPowerUpRangoObjects1});
gdjs.Sala_32_6Code.mapOfEmptyGDMiniJefeObjects = Hashtable.newFrom({"MiniJefe": []});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPowerUpRangoObjects1Objects = Hashtable.newFrom({"PowerUpRango": gdjs.Sala_32_6Code.GDPowerUpRangoObjects1});
gdjs.Sala_32_6Code.mapOfEmptyGDMiniJefeObjects = Hashtable.newFrom({"MiniJefe": []});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDFarolCheckpointObjects1Objects = Hashtable.newFrom({"FarolCheckpoint": gdjs.Sala_32_6Code.GDFarolCheckpointObjects1});
gdjs.Sala_32_6Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 3;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(21)) + 5;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1, gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);

{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡MANTO DEL FAROL OBTENIDO (+ESCUDO)!");
}
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(21).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects = Hashtable.newFrom({"MiniJefe": gdjs.Sala_32_6Code.GDMiniJefeObjects1});
gdjs.Sala_32_6Code.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vida")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(5);
}
{runtimeScene.getGame().getVariables().getFromIndex(23).setNumber(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Meta", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡CARCELERO DERROTADO!");
}
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects = Hashtable.newFrom({"MiniJefe": gdjs.Sala_32_6Code.GDMiniJefeObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects = Hashtable.newFrom({"MiniJefe": gdjs.Sala_32_6Code.GDMiniJefeObjects1});
gdjs.Sala_32_6Code.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vida")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(5);
}
{runtimeScene.getGame().getVariables().getFromIndex(23).setNumber(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Meta", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡CARCELERO DERROTADO!");
}
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects = Hashtable.newFrom({"MiniJefe": gdjs.Sala_32_6Code.GDMiniJefeObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects = Hashtable.newFrom({"MiniJefe": gdjs.Sala_32_6Code.GDMiniJefeObjects1});
gdjs.Sala_32_6Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(18).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].setY(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].getBehavior("PlatformerObject").setCurrentFallSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(3)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(11)).setNumber(1.2);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(0);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡REGRESO AL FAROL DE REPOSO!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(18).getAsNumber() == 0);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(0);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Muerte", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


};gdjs.Sala_32_6Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(0);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(5.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.15);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡MANTO DEL FAROL ABSORBIÓ EL IMPACTO!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 0;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dano", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(9.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.22);
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.Sala_32_6Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(18).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].setY(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].getBehavior("PlatformerObject").setCurrentFallSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(3)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects2[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(11)).setNumber(1.2);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(0);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡REGRESO AL FAROL DE REPOSO!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(18).getAsNumber() == 0);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(0);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Muerte", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPuertaObjects1Objects = Hashtable.newFrom({"Puerta": gdjs.Sala_32_6Code.GDPuertaObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaIzqObjects1Objects = Hashtable.newFrom({"OndaIzq": gdjs.Sala_32_6Code.GDOndaIzqObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaDerObjects1Objects = Hashtable.newFrom({"OndaDer": gdjs.Sala_32_6Code.GDOndaDerObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaIzqObjects1Objects = Hashtable.newFrom({"OndaIzq": gdjs.Sala_32_6Code.GDOndaIzqObjects1});
gdjs.Sala_32_6Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);
gdjs.copyArray(gdjs.Sala_32_6Code.GDOndaIzqObjects1, gdjs.Sala_32_6Code.GDOndaIzqObjects2);

{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(0);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaIzqObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaIzqObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(5.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.15);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡MANTO DEL FAROL ABSORBIÓ EL IMPACTO!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 0;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDOndaIzqObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dano", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaIzqObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaDerObjects1Objects = Hashtable.newFrom({"OndaDer": gdjs.Sala_32_6Code.GDOndaDerObjects1});
gdjs.Sala_32_6Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);
gdjs.copyArray(gdjs.Sala_32_6Code.GDOndaDerObjects1, gdjs.Sala_32_6Code.GDOndaDerObjects2);

{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(0);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaDerObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaDerObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(5.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.15);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡MANTO DEL FAROL ABSORBIÓ EL IMPACTO!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 0;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDOndaDerObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dano", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaDerObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaDerObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects = Hashtable.newFrom({"Jefe": gdjs.Sala_32_6Code.GDJefeObjects1});
gdjs.Sala_32_6Code.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(0);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(5.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.15);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2[i].setString("¡MANTO DEL FAROL ABSORBIÓ EL IMPACTO!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(20)) == 0;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dano", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects = Hashtable.newFrom({"Jefe": gdjs.Sala_32_6Code.GDJefeObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects = Hashtable.newFrom({"Jefe": gdjs.Sala_32_6Code.GDJefeObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects = Hashtable.newFrom({"GolpePala": gdjs.Sala_32_6Code.GDGolpePalaObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects = Hashtable.newFrom({"Jefe": gdjs.Sala_32_6Code.GDJefeObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects = Hashtable.newFrom({"Jefe": gdjs.Sala_32_6Code.GDJefeObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects = Hashtable.newFrom({"Jugador": gdjs.Sala_32_6Code.GDJugadorObjects1});
gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects = Hashtable.newFrom({"Jefe": gdjs.Sala_32_6Code.GDJefeObjects1});
gdjs.Sala_32_6Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 1;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(0);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(16);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(512);
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(192);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.25, "", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 512, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 192, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "UI", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 640, "UI", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 360, "UI", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(18).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(19).getAsString() == gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setY(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "F1");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Escape");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "p");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "P");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pausa");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "A");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)).setNumber(-1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "D");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "W");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "z");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Z");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(9)).setNumber(0.12);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(8)).setNumber(0.1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(620);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(8)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(9)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(9)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(9)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Sala_32_6Code.GDJugadorObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects2.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects2[k] = gdjs.Sala_32_6Code.GDJugadorObjects2[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Sala_32_6Code.GDJugadorObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Sala_32_6Code.GDJugadorObjects1_1final.indexOf(gdjs.Sala_32_6Code.GDJugadorObjects2[j]) === -1 )
            gdjs.Sala_32_6Code.GDJugadorObjects1_1final.push(gdjs.Sala_32_6Code.GDJugadorObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects2.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(8)) > 0 ) {
        isConditionTrue_1 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects2[k] = gdjs.Sala_32_6Code.GDJugadorObjects2[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Sala_32_6Code.GDJugadorObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Sala_32_6Code.GDJugadorObjects1_1final.indexOf(gdjs.Sala_32_6Code.GDJugadorObjects2[j]) === -1 )
            gdjs.Sala_32_6Code.GDJugadorObjects1_1final.push(gdjs.Sala_32_6Code.GDJugadorObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1_1final, gdjs.Sala_32_6Code.GDJugadorObjects1);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(620);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Salto", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(9)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(8)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "W"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "z"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Z"));
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").abortJump();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "j");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "J");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "z");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Z");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "k");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "K");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "c");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "C");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "\"Left\"");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(14)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)).setNumber(1);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Pala", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)).setNumber(0.2);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(14)).setNumber(0.35);
}
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) <= 0.12 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) > 0.06 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].setAnimation(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) <= 0.06 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].setAnimation(2);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) <= 0.12 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) > 0.06 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].setAnimation(4);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) <= 0.06 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].setAnimation(5);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(13)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(14)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(14)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDGolpePalaObjects1[k] = gdjs.Sala_32_6Code.GDGolpePalaObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].getVariables().getFromIndex(0)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDGolpePalaObjects1[k] = gdjs.Sala_32_6Code.GDGolpePalaObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(14);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(15);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(2);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(5);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(12);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(13);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(7);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(4);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(9);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(10);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(11);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(6);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(3);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(12)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].setAnimation(8);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Sala_32_6Code.GDJugadorObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects2.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects2[k] = gdjs.Sala_32_6Code.GDJugadorObjects2[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Sala_32_6Code.GDJugadorObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Sala_32_6Code.GDJugadorObjects1_1final.indexOf(gdjs.Sala_32_6Code.GDJugadorObjects2[j]) === -1 )
            gdjs.Sala_32_6Code.GDJugadorObjects1_1final.push(gdjs.Sala_32_6Code.GDJugadorObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects2.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(8)) > 0 ) {
        isConditionTrue_1 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects2[k] = gdjs.Sala_32_6Code.GDJugadorObjects2[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Sala_32_6Code.GDJugadorObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Sala_32_6Code.GDJugadorObjects1_1final.indexOf(gdjs.Sala_32_6Code.GDJugadorObjects2[j]) === -1 )
            gdjs.Sala_32_6Code.GDJugadorObjects1_1final.push(gdjs.Sala_32_6Code.GDJugadorObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1_1final, gdjs.Sala_32_6Code.GDJugadorObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Sala_32_6Code.GDJugadorObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "w");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "W");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "z");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Z");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1, gdjs.Sala_32_6Code.GDJugadorObjects2);

for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects2.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects2[i].getVariables().getFromIndex(9)) > 0 ) {
        isConditionTrue_1 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects2[k] = gdjs.Sala_32_6Code.GDJugadorObjects2[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Sala_32_6Code.GDJugadorObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Sala_32_6Code.GDJugadorObjects1_1final.indexOf(gdjs.Sala_32_6Code.GDJugadorObjects2[j]) === -1 )
            gdjs.Sala_32_6Code.GDJugadorObjects1_1final.push(gdjs.Sala_32_6Code.GDJugadorObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Sala_32_6Code.GDJugadorObjects1_1final, gdjs.Sala_32_6Code.GDJugadorObjects1);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(7)).setNumber(0.06);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(295);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(620);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0))) * 295);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(9)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(8)).setNumber(0);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Salto", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "x");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "X");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)).setNumber(1);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dash", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(3.5);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(4)).setNumber(0.2);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).setNumber(0.6);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(560.0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(0, false);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0))) * 560.0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "x");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "X");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)).setNumber(1);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dash", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(3.5);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(4)).setNumber(0.2);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).setNumber(0.6);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(560.0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(0, false);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0))) * 560.0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(4)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0))) * 560.0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentFallSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(4)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(4)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(7)).setNumber(0.06);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(250);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(900, false);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(0))) * 250);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(11)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(11)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(14).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber() + (Math.min(Math.max((( gdjs.Sala_32_6Code.GDJugadorObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJugadorObjects1[0].getPointX("")) + 16, 512), 3008) - runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber()) * Math.min(1, 7.0 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() + (Math.min(Math.max((( gdjs.Sala_32_6Code.GDJugadorObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJugadorObjects1[0].getPointY("")) + 16, 192), 192) - runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber()) * Math.min(1, 7.0 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber() + gdjs.randomInRange(-(((1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) * (runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber() * Math.max(0, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber()) / 0.18))), ((1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) * (runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber() * Math.max(0, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber()) / 0.18))), "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() + gdjs.randomInRange(-(((1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) * (runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber() * Math.max(0, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber()) / 0.18))), ((1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) * (runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber() * Math.max(0, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber()) / 0.18))), "", 0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alma"), gdjs.Sala_32_6Code.GDAlmaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDAlmaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDAlmaObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDAlmaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDAlmaObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(1.3);
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() > 0);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PalaRecogible"), gdjs.Sala_32_6Code.GDPalaRecogibleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPalaRecogibleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDPalaRecogibleObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDPalaRecogibleObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDPalaRecogibleObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_PalaRecoger", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PowerUpRango"), gdjs.Sala_32_6Code.GDPowerUpRangoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPowerUpRangoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.Sala_32_6Code.mapOfEmptyGDMiniJefeObjects) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡ALTAR SELLADO! Derrota al Carcelero");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PowerUpRango"), gdjs.Sala_32_6Code.GDPowerUpRangoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPowerUpRangoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.Sala_32_6Code.mapOfEmptyGDMiniJefeObjects) <= 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
/* Reuse gdjs.Sala_32_6Code.GDPowerUpRangoObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDPowerUpRangoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDPowerUpRangoObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Meta", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(4.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.12);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡ALCANCE DE PALA MEJORADO!");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("FarolCheckpoint"), gdjs.Sala_32_6Code.GDFarolCheckpointObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDFarolCheckpointObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[k] = gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDFarolCheckpointObjects1 */
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[i].setAnimation(1);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber((( gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[0].getPointX("")));
}
{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber((( gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDFarolCheckpointObjects1[0].getPointY("")));
}
{runtimeScene.getGame().getVariables().getFromIndex(19).setString(gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Alma", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡PUNTO DE CONTROL ALCANZADO!");
}
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getX() >= (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(2))) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)).setNumber(-1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getX() <= (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(1))) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].setX((gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getPointX("")) + (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0))) * 70 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(0.55);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getX() > (( gdjs.Sala_32_6Code.GDMiniJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDMiniJefeObjects1[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getX() <= (( gdjs.Sala_32_6Code.GDMiniJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDMiniJefeObjects1[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)).setNumber(-1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(2);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(0.4);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].setX((gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getPointX("")) + (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0))) * 220 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(3);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(1.30);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡EL CARCELERO ESTÁ CANSADO! ¡ATACA AHORA!");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(1.20);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getY() < (( gdjs.Sala_32_6Code.GDMiniJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDMiniJefeObjects1[0].getPointY("")) - 10 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vida")).sub(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(0.50);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(570.4);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(11)).setNumber(0.4);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Stomp", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(6.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.18);
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getY() < (( gdjs.Sala_32_6Code.GDMiniJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDMiniJefeObjects1[0].getPointY("")) - 10 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(230);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(0.45);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Stomp", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡ARMADURA IMPENETRABLE! Espera a que se canse");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vida")).sub(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("estado")).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("timer")).setNumber(0.50);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Golpe", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(5.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.12);
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().get("vulnerable")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Golpe", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(3.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡ARMADURA IMPENETRABLE! Espera a que se canse");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDMiniJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getY() >= (( gdjs.Sala_32_6Code.GDMiniJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDMiniJefeObjects1[0].getPointY("")) - 10 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Sala_32_6Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MiniJefe"), gdjs.Sala_32_6Code.GDMiniJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDMiniJefeObjects1[k] = gdjs.Sala_32_6Code.GDMiniJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDMiniJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDMiniJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDMiniJefeObjects1[i].flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getY() > 504 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(11)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Dano", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(9.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.22);
}

{ //Subevents
gdjs.Sala_32_6Code.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Puerta"), gdjs.Sala_32_6Code.GDPuertaObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDPuertaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Meta", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).add(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HUD_Almas"), gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUD_Vidas"), gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1[i].setString("ALMAS " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))) + " · VIDA +" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))) + "/10");
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1[i].setString("VIDAS " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))) + "/5");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡ÚLTIMA VIDA!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Dash"), gdjs.Sala_32_6Code.GDHUD_9595DashObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595DashObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595DashObjects1[i].setString("ESPACIO: SALTO · SHIFT: DASH · A: PALA");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Dash"), gdjs.Sala_32_6Code.GDHUD_9595DashObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595DashObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595DashObjects1[i].setString("ESPACIO: SALTO · SHIFT: DASH");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(0.8);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
gdjs.Sala_32_6Code.GDOndaDerObjects1.length = 0;

gdjs.Sala_32_6Code.GDOndaIzqObjects1.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Golpe", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(8.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.2);
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaIzqObjects1Objects, (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getPointX("")), (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getPointY("")) + (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getHeight()) / 2, "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaDerObjects1Objects, (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getPointX("")) + (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getWidth()), (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getPointY("")) + (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getHeight()) / 2, "");
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaIzqObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].getVariables().getFromIndex(1)).setNumber(Math.round(300.0 * (0.7 + (gdjs.RuntimeObject.getVariableNumber(((gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Sala_32_6Code.GDJefeObjects1[0].getVariables()).getFromIndex(1))) * 0.2)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaDerObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaDerObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDOndaDerObjects1[i].getVariables().getFromIndex(1)).setNumber(Math.round(300.0 * (0.7 + (gdjs.RuntimeObject.getVariableNumber(((gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Sala_32_6Code.GDJefeObjects1[0].getVariables()).getFromIndex(1))) * 0.2)));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(2);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(0.3);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(3);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(1.5);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(2.0 - (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1))) * 0.4);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getX() >= (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("max_x"))) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir")).setNumber(-1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir")) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getX() <= (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("min_x"))) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir")).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].setX((gdjs.Sala_32_6Code.GDJefeObjects1[i].getPointX("")) + (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir"))) * 120 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("OndaDer"), gdjs.Sala_32_6Code.GDOndaDerObjects1);
gdjs.copyArray(runtimeScene.getObjects("OndaIzq"), gdjs.Sala_32_6Code.GDOndaIzqObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaIzqObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].setX((gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].getPointX("")) - (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].getVariables().getFromIndex(1))) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaDerObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaDerObjects1[i].setX((gdjs.Sala_32_6Code.GDOndaDerObjects1[i].getPointX("")) + (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDOndaDerObjects1[i].getVariables().getFromIndex(1))) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("OndaIzq"), gdjs.Sala_32_6Code.GDOndaIzqObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDOndaIzqObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].getX() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDOndaIzqObjects1[k] = gdjs.Sala_32_6Code.GDOndaIzqObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDOndaIzqObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDOndaIzqObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaIzqObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("OndaDer"), gdjs.Sala_32_6Code.GDOndaDerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDOndaDerObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDOndaDerObjects1[i].getX() > 1280 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDOndaDerObjects1[k] = gdjs.Sala_32_6Code.GDOndaDerObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDOndaDerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDOndaDerObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaDerObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaDerObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("OndaIzq"), gdjs.Sala_32_6Code.GDOndaIzqObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaIzqObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Sala_32_6Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("OndaDer"), gdjs.Sala_32_6Code.GDOndaDerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDOndaDerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Sala_32_6Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Sala_32_6Code.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)) < 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(5)).add(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(2.0);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Golpe", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)) >= 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber() == 1);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(5)).add(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(2.0);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Golpe", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GolpePala"), gdjs.Sala_32_6Code.GDGolpePalaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDGolpePalaObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)) >= 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber() == 0);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDGolpePalaObjects1 */
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Golpe", false, 100, 1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDGolpePalaObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDGolpePalaObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(4.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.12);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡CORAZA CARMESÍ! Necesitas la Guadaña (X)");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir")) == -1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().get("dir")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getY() <= (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getPointY("")) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)) < 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(2.0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(570.4);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(11)).setNumber(0.4);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Stomp", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(6.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.18);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJugadorObjects1Objects, gdjs.Sala_32_6Code.mapOfGDgdjs_9546Sala_9595326Code_9546GDJefeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getY() <= (( gdjs.Sala_32_6Code.GDJefeObjects1.length === 0 ) ? 0 :gdjs.Sala_32_6Code.GDJefeObjects1[0].getPointY("")) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)) >= 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber() == 1);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(2.0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(570.4);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(6)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(11)).setNumber(0.4);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Stomp", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(6.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.18);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(0)) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1))) * 2 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)) < 3 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(1)).add(1);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(5)).setNumber(0);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(11.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.26);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(3)).setNumber(1.0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(4)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jefe"), gdjs.Sala_32_6Code.GDJefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJefeObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJefeObjects1[k] = gdjs.Sala_32_6Code.GDJefeObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJefeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUD_Aviso"), gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1);
/* Reuse gdjs.Sala_32_6Code.GDJefeObjects1 */
gdjs.copyArray(runtimeScene.getObjects("OndaDer"), gdjs.Sala_32_6Code.GDOndaDerObjects1);
gdjs.copyArray(runtimeScene.getObjects("OndaIzq"), gdjs.Sala_32_6Code.GDOndaIzqObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJefeObjects1[i].getVariables().getFromIndex(2)).setNumber(4);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJefeObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJefeObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(8.0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0.18);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaIzqObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaIzqObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDOndaDerObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDOndaDerObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_Meta", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).add(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(1);
}
{for(var i = 0, len = gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1[i].setString("¡SALIDA ABIERTA!");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(10)).setNumber(1500);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").getCurrentJumpSpeed() < 70 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(10)).setNumber(825);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( !(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").getCurrentFallSpeed() < 70 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(10)).setNumber(825);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(7)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(10)).setNumber(750);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Sala_32_6Code.GDJugadorObjects1.length;i<l;++i) {
    if ( gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Sala_32_6Code.GDJugadorObjects1[k] = gdjs.Sala_32_6Code.GDJugadorObjects1[i];
        ++k;
    }
}
gdjs.Sala_32_6Code.GDJugadorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Sala_32_6Code.GDJugadorObjects1 */
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].returnVariable(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(10)).setNumber(0);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Jugador"), gdjs.Sala_32_6Code.GDJugadorObjects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDJugadorObjects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDJugadorObjects1[i].getBehavior("PlatformerObject").setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.Sala_32_6Code.GDJugadorObjects1[i].getVariables().getFromIndex(10))));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlataformaMovil_1"), gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1);
{for(var i = 0, len = gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1.length ;i < len;++i) {
    gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1[i].setPosition(1344 + Math.sin(gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) * 1.35 + 4.4436) * 96,224);
}
}
}

}


};

gdjs.Sala_32_6Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Sala_32_6Code.GDFondoObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects3.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects1.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects2.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects3.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects1.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects2.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects3.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects1.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects2.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects3.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects3.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects2.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects3.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects1.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects2.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects3.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects1.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects2.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects3.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects2.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects3.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects1.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects2.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoTituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoTituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoTituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoPausaObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoPausaObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoPausaObjects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoDerrotaObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoDerrotaObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoDerrotaObjects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoVictoriaObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoVictoriaObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoVictoriaObjects3.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects1.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects2.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects3.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects1.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects2.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoSalasObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoSalasObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoSalasObjects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects3.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects1.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects2.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects3.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects1.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects2.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects3.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects1.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects2.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects3.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects3.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects2.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects3.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects1.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects2.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects2.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects3.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects1.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects2.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects3.length = 0;
gdjs.Sala_32_6Code.GDEnemyObjects1.length = 0;
gdjs.Sala_32_6Code.GDEnemyObjects2.length = 0;
gdjs.Sala_32_6Code.GDEnemyObjects3.length = 0;
gdjs.Sala_32_6Code.GDPowerUpDashObjects1.length = 0;
gdjs.Sala_32_6Code.GDPowerUpDashObjects2.length = 0;
gdjs.Sala_32_6Code.GDPowerUpDashObjects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects3.length = 0;
gdjs.Sala_32_6Code.GDEnemyMeleeObjects1.length = 0;
gdjs.Sala_32_6Code.GDEnemyMeleeObjects2.length = 0;
gdjs.Sala_32_6Code.GDEnemyMeleeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPinchosObjects1.length = 0;
gdjs.Sala_32_6Code.GDPinchosObjects2.length = 0;
gdjs.Sala_32_6Code.GDPinchosObjects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects3.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects1.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects2.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects3.length = 0;

gdjs.Sala_32_6Code.eventsList13(runtimeScene);
gdjs.Sala_32_6Code.GDFondoObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects3.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects1.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects2.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects3.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects1.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects2.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects3.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects1.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects2.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects3.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects3.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects2.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects3.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects1.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects2.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects3.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects1.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects2.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects3.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects2.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects3.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects1.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects2.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoTituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoTituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoTituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op1_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op2_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op3_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4Objects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595Op4_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects1.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects2.length = 0;
gdjs.Sala_32_6Code.GDMenu_9595AyudaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoPausaObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoPausaObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoPausaObjects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion1Objects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion2Objects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595Opcion3Objects3.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects1.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects2.length = 0;
gdjs.Sala_32_6Code.GDPausa_9595AyudaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoDerrotaObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoDerrotaObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoDerrotaObjects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595CausaObjects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat1Objects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595Stat2Objects3.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects1.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects2.length = 0;
gdjs.Sala_32_6Code.GDDerrota_9595PromptObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoVictoriaObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoVictoriaObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoVictoriaObjects3.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects1.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects2.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595StatsObjects3.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects1.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects2.length = 0;
gdjs.Sala_32_6Code.GDVictoria_9595PromptObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoSalasObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoSalasObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoSalasObjects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595TituloObjects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595SubObjects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595SubObjects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595SubObjects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion1Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion2Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion3Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion4Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion5Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Opcion6Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc1Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595Desc2Objects3.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects1.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects2.length = 0;
gdjs.Sala_32_6Code.GDSalas_9595AyudaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects1.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects2.length = 0;
gdjs.Sala_32_6Code.GDFondoObjects3.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects1.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects2.length = 0;
gdjs.Sala_32_6Code.GDSolidoObjects3.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects1.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects2.length = 0;
gdjs.Sala_32_6Code.GDJugadorObjects3.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects1.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects2.length = 0;
gdjs.Sala_32_6Code.GDPuertaObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595BarraObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595NivelObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AlmasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595VidasObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595AvisoObjects3.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects1.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects2.length = 0;
gdjs.Sala_32_6Code.GDHUD_9595DashObjects3.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaIzqObjects3.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects1.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects2.length = 0;
gdjs.Sala_32_6Code.GDOndaDerObjects3.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects1.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects2.length = 0;
gdjs.Sala_32_6Code.GDGolpePalaObjects3.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects1.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects2.length = 0;
gdjs.Sala_32_6Code.GDAlmaObjects3.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects1.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects2.length = 0;
gdjs.Sala_32_6Code.GDFarolCheckpointObjects3.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects1.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects2.length = 0;
gdjs.Sala_32_6Code.GDPalaRecogibleObjects3.length = 0;
gdjs.Sala_32_6Code.GDEnemyObjects1.length = 0;
gdjs.Sala_32_6Code.GDEnemyObjects2.length = 0;
gdjs.Sala_32_6Code.GDEnemyObjects3.length = 0;
gdjs.Sala_32_6Code.GDPowerUpDashObjects1.length = 0;
gdjs.Sala_32_6Code.GDPowerUpDashObjects2.length = 0;
gdjs.Sala_32_6Code.GDPowerUpDashObjects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95951Objects3.length = 0;
gdjs.Sala_32_6Code.GDEnemyMeleeObjects1.length = 0;
gdjs.Sala_32_6Code.GDEnemyMeleeObjects2.length = 0;
gdjs.Sala_32_6Code.GDEnemyMeleeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPinchosObjects1.length = 0;
gdjs.Sala_32_6Code.GDPinchosObjects2.length = 0;
gdjs.Sala_32_6Code.GDPinchosObjects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95952Objects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95953Objects3.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.Sala_32_6Code.GDPlataformaMovil_95954Objects3.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects1.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects2.length = 0;
gdjs.Sala_32_6Code.GDMiniJefeObjects3.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects1.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects2.length = 0;
gdjs.Sala_32_6Code.GDPowerUpRangoObjects3.length = 0;


return;

}

gdjs['Sala_326Code'] = gdjs.Sala_32_6Code;
