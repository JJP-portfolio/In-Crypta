gdjs.DerrotaCode = {};
gdjs.DerrotaCode.localVariables = [];
gdjs.DerrotaCode.idToCallbackMap = new Map();
gdjs.DerrotaCode.GDFondoDerrotaObjects1= [];
gdjs.DerrotaCode.GDFondoDerrotaObjects2= [];
gdjs.DerrotaCode.GDFondoDerrotaObjects3= [];
gdjs.DerrotaCode.GDDerrota_9595TituloObjects1= [];
gdjs.DerrotaCode.GDDerrota_9595TituloObjects2= [];
gdjs.DerrotaCode.GDDerrota_9595TituloObjects3= [];
gdjs.DerrotaCode.GDDerrota_9595CausaObjects1= [];
gdjs.DerrotaCode.GDDerrota_9595CausaObjects2= [];
gdjs.DerrotaCode.GDDerrota_9595CausaObjects3= [];
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1= [];
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects2= [];
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects3= [];
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1= [];
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects2= [];
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects3= [];
gdjs.DerrotaCode.GDDerrota_9595PromptObjects1= [];
gdjs.DerrotaCode.GDDerrota_9595PromptObjects2= [];
gdjs.DerrotaCode.GDDerrota_9595PromptObjects3= [];
gdjs.DerrotaCode.GDFondoTituloObjects1= [];
gdjs.DerrotaCode.GDFondoTituloObjects2= [];
gdjs.DerrotaCode.GDFondoTituloObjects3= [];
gdjs.DerrotaCode.GDMenu_9595TituloObjects1= [];
gdjs.DerrotaCode.GDMenu_9595TituloObjects2= [];
gdjs.DerrotaCode.GDMenu_9595TituloObjects3= [];
gdjs.DerrotaCode.GDMenu_9595SubObjects1= [];
gdjs.DerrotaCode.GDMenu_9595SubObjects2= [];
gdjs.DerrotaCode.GDMenu_9595SubObjects3= [];
gdjs.DerrotaCode.GDMenu_9595Op1Objects1= [];
gdjs.DerrotaCode.GDMenu_9595Op1Objects2= [];
gdjs.DerrotaCode.GDMenu_9595Op1Objects3= [];
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects1= [];
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects2= [];
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects3= [];
gdjs.DerrotaCode.GDMenu_9595Op2Objects1= [];
gdjs.DerrotaCode.GDMenu_9595Op2Objects2= [];
gdjs.DerrotaCode.GDMenu_9595Op2Objects3= [];
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects1= [];
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects2= [];
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects3= [];
gdjs.DerrotaCode.GDMenu_9595Op3Objects1= [];
gdjs.DerrotaCode.GDMenu_9595Op3Objects2= [];
gdjs.DerrotaCode.GDMenu_9595Op3Objects3= [];
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects1= [];
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects2= [];
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects3= [];
gdjs.DerrotaCode.GDMenu_9595Op4Objects1= [];
gdjs.DerrotaCode.GDMenu_9595Op4Objects2= [];
gdjs.DerrotaCode.GDMenu_9595Op4Objects3= [];
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects1= [];
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects2= [];
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects3= [];
gdjs.DerrotaCode.GDMenu_9595AyudaObjects1= [];
gdjs.DerrotaCode.GDMenu_9595AyudaObjects2= [];
gdjs.DerrotaCode.GDMenu_9595AyudaObjects3= [];
gdjs.DerrotaCode.GDFondoPausaObjects1= [];
gdjs.DerrotaCode.GDFondoPausaObjects2= [];
gdjs.DerrotaCode.GDFondoPausaObjects3= [];
gdjs.DerrotaCode.GDPausa_9595TituloObjects1= [];
gdjs.DerrotaCode.GDPausa_9595TituloObjects2= [];
gdjs.DerrotaCode.GDPausa_9595TituloObjects3= [];
gdjs.DerrotaCode.GDPausa_9595SubObjects1= [];
gdjs.DerrotaCode.GDPausa_9595SubObjects2= [];
gdjs.DerrotaCode.GDPausa_9595SubObjects3= [];
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects1= [];
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects2= [];
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects3= [];
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects1= [];
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects2= [];
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects3= [];
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects1= [];
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects2= [];
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects3= [];
gdjs.DerrotaCode.GDPausa_9595AyudaObjects1= [];
gdjs.DerrotaCode.GDPausa_9595AyudaObjects2= [];
gdjs.DerrotaCode.GDPausa_9595AyudaObjects3= [];
gdjs.DerrotaCode.GDFondoDerrotaObjects1= [];
gdjs.DerrotaCode.GDFondoDerrotaObjects2= [];
gdjs.DerrotaCode.GDFondoDerrotaObjects3= [];
gdjs.DerrotaCode.GDDerrota_9595TituloObjects1= [];
gdjs.DerrotaCode.GDDerrota_9595TituloObjects2= [];
gdjs.DerrotaCode.GDDerrota_9595TituloObjects3= [];
gdjs.DerrotaCode.GDDerrota_9595CausaObjects1= [];
gdjs.DerrotaCode.GDDerrota_9595CausaObjects2= [];
gdjs.DerrotaCode.GDDerrota_9595CausaObjects3= [];
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1= [];
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects2= [];
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects3= [];
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1= [];
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects2= [];
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects3= [];
gdjs.DerrotaCode.GDDerrota_9595PromptObjects1= [];
gdjs.DerrotaCode.GDDerrota_9595PromptObjects2= [];
gdjs.DerrotaCode.GDDerrota_9595PromptObjects3= [];
gdjs.DerrotaCode.GDFondoVictoriaObjects1= [];
gdjs.DerrotaCode.GDFondoVictoriaObjects2= [];
gdjs.DerrotaCode.GDFondoVictoriaObjects3= [];
gdjs.DerrotaCode.GDVictoria_9595TituloObjects1= [];
gdjs.DerrotaCode.GDVictoria_9595TituloObjects2= [];
gdjs.DerrotaCode.GDVictoria_9595TituloObjects3= [];
gdjs.DerrotaCode.GDVictoria_9595StatsObjects1= [];
gdjs.DerrotaCode.GDVictoria_9595StatsObjects2= [];
gdjs.DerrotaCode.GDVictoria_9595StatsObjects3= [];
gdjs.DerrotaCode.GDVictoria_9595PromptObjects1= [];
gdjs.DerrotaCode.GDVictoria_9595PromptObjects2= [];
gdjs.DerrotaCode.GDVictoria_9595PromptObjects3= [];
gdjs.DerrotaCode.GDFondoSalasObjects1= [];
gdjs.DerrotaCode.GDFondoSalasObjects2= [];
gdjs.DerrotaCode.GDFondoSalasObjects3= [];
gdjs.DerrotaCode.GDSalas_9595TituloObjects1= [];
gdjs.DerrotaCode.GDSalas_9595TituloObjects2= [];
gdjs.DerrotaCode.GDSalas_9595TituloObjects3= [];
gdjs.DerrotaCode.GDSalas_9595SubObjects1= [];
gdjs.DerrotaCode.GDSalas_9595SubObjects2= [];
gdjs.DerrotaCode.GDSalas_9595SubObjects3= [];
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Desc1Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Desc1Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Desc1Objects3= [];
gdjs.DerrotaCode.GDSalas_9595Desc2Objects1= [];
gdjs.DerrotaCode.GDSalas_9595Desc2Objects2= [];
gdjs.DerrotaCode.GDSalas_9595Desc2Objects3= [];
gdjs.DerrotaCode.GDSalas_9595AyudaObjects1= [];
gdjs.DerrotaCode.GDSalas_9595AyudaObjects2= [];
gdjs.DerrotaCode.GDSalas_9595AyudaObjects3= [];
gdjs.DerrotaCode.GDFondoObjects1= [];
gdjs.DerrotaCode.GDFondoObjects2= [];
gdjs.DerrotaCode.GDFondoObjects3= [];
gdjs.DerrotaCode.GDSolidoObjects1= [];
gdjs.DerrotaCode.GDSolidoObjects2= [];
gdjs.DerrotaCode.GDSolidoObjects3= [];
gdjs.DerrotaCode.GDJugadorObjects1= [];
gdjs.DerrotaCode.GDJugadorObjects2= [];
gdjs.DerrotaCode.GDJugadorObjects3= [];
gdjs.DerrotaCode.GDPuertaObjects1= [];
gdjs.DerrotaCode.GDPuertaObjects2= [];
gdjs.DerrotaCode.GDPuertaObjects3= [];
gdjs.DerrotaCode.GDHUD_9595BarraObjects1= [];
gdjs.DerrotaCode.GDHUD_9595BarraObjects2= [];
gdjs.DerrotaCode.GDHUD_9595BarraObjects3= [];
gdjs.DerrotaCode.GDHUD_9595NivelObjects1= [];
gdjs.DerrotaCode.GDHUD_9595NivelObjects2= [];
gdjs.DerrotaCode.GDHUD_9595NivelObjects3= [];
gdjs.DerrotaCode.GDHUD_9595AlmasObjects1= [];
gdjs.DerrotaCode.GDHUD_9595AlmasObjects2= [];
gdjs.DerrotaCode.GDHUD_9595AlmasObjects3= [];
gdjs.DerrotaCode.GDHUD_9595VidasObjects1= [];
gdjs.DerrotaCode.GDHUD_9595VidasObjects2= [];
gdjs.DerrotaCode.GDHUD_9595VidasObjects3= [];
gdjs.DerrotaCode.GDHUD_9595AvisoObjects1= [];
gdjs.DerrotaCode.GDHUD_9595AvisoObjects2= [];
gdjs.DerrotaCode.GDHUD_9595AvisoObjects3= [];
gdjs.DerrotaCode.GDHUD_9595DashObjects1= [];
gdjs.DerrotaCode.GDHUD_9595DashObjects2= [];
gdjs.DerrotaCode.GDHUD_9595DashObjects3= [];
gdjs.DerrotaCode.GDJefeObjects1= [];
gdjs.DerrotaCode.GDJefeObjects2= [];
gdjs.DerrotaCode.GDJefeObjects3= [];
gdjs.DerrotaCode.GDOndaIzqObjects1= [];
gdjs.DerrotaCode.GDOndaIzqObjects2= [];
gdjs.DerrotaCode.GDOndaIzqObjects3= [];
gdjs.DerrotaCode.GDOndaDerObjects1= [];
gdjs.DerrotaCode.GDOndaDerObjects2= [];
gdjs.DerrotaCode.GDOndaDerObjects3= [];
gdjs.DerrotaCode.GDGolpePalaObjects1= [];
gdjs.DerrotaCode.GDGolpePalaObjects2= [];
gdjs.DerrotaCode.GDGolpePalaObjects3= [];
gdjs.DerrotaCode.GDAlmaObjects1= [];
gdjs.DerrotaCode.GDAlmaObjects2= [];
gdjs.DerrotaCode.GDAlmaObjects3= [];
gdjs.DerrotaCode.GDFarolCheckpointObjects1= [];
gdjs.DerrotaCode.GDFarolCheckpointObjects2= [];
gdjs.DerrotaCode.GDFarolCheckpointObjects3= [];
gdjs.DerrotaCode.GDPalaRecogibleObjects1= [];
gdjs.DerrotaCode.GDPalaRecogibleObjects2= [];
gdjs.DerrotaCode.GDPalaRecogibleObjects3= [];
gdjs.DerrotaCode.GDEnemyObjects1= [];
gdjs.DerrotaCode.GDEnemyObjects2= [];
gdjs.DerrotaCode.GDEnemyObjects3= [];
gdjs.DerrotaCode.GDPowerUpDashObjects1= [];
gdjs.DerrotaCode.GDPowerUpDashObjects2= [];
gdjs.DerrotaCode.GDPowerUpDashObjects3= [];
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects1= [];
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects2= [];
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects3= [];
gdjs.DerrotaCode.GDEnemyMeleeObjects1= [];
gdjs.DerrotaCode.GDEnemyMeleeObjects2= [];
gdjs.DerrotaCode.GDEnemyMeleeObjects3= [];
gdjs.DerrotaCode.GDPinchosObjects1= [];
gdjs.DerrotaCode.GDPinchosObjects2= [];
gdjs.DerrotaCode.GDPinchosObjects3= [];
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects1= [];
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects2= [];
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects3= [];
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects1= [];
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects2= [];
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects3= [];
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects1= [];
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects2= [];
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects3= [];
gdjs.DerrotaCode.GDMiniJefeObjects1= [];
gdjs.DerrotaCode.GDMiniJefeObjects2= [];
gdjs.DerrotaCode.GDMiniJefeObjects3= [];
gdjs.DerrotaCode.GDPowerUpRangoObjects1= [];
gdjs.DerrotaCode.GDPowerUpRangoObjects2= [];
gdjs.DerrotaCode.GDPowerUpRangoObjects3= [];


gdjs.DerrotaCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Nivel 1", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 2);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Nivel 2", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 3);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Nivel 3", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 11);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sala 1", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 12);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sala 2", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 13);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sala 3", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 14);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sala 4", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 15);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sala 5", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber() == 16);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sala 6", false);
}
}

}


};gdjs.DerrotaCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Derrota_Stat1"), gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Derrota_Stat2"), gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1);
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(512);
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(288);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.25, "", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 512, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 288, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "UI", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 640, "UI", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 360, "UI", 0);
}
{for(var i = 0, len = gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1.length ;i < len;++i) {
    gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1[i].setString("CAÍDAS TOTALES: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))));
}
}
{for(var i = 0, len = gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1.length ;i < len;++i) {
    gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1[i].setString("ALMAS COSECHADAS: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}

{ //Subevents
gdjs.DerrotaCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Titulo", false);
}
}

}


};

gdjs.DerrotaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DerrotaCode.GDFondoDerrotaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects3.length = 0;
gdjs.DerrotaCode.GDFondoTituloObjects1.length = 0;
gdjs.DerrotaCode.GDFondoTituloObjects2.length = 0;
gdjs.DerrotaCode.GDFondoTituloObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595AyudaObjects3.length = 0;
gdjs.DerrotaCode.GDFondoPausaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoPausaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoPausaObjects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595AyudaObjects3.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects3.length = 0;
gdjs.DerrotaCode.GDFondoVictoriaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoVictoriaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoVictoriaObjects3.length = 0;
gdjs.DerrotaCode.GDVictoria_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDVictoria_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDVictoria_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDVictoria_9595StatsObjects1.length = 0;
gdjs.DerrotaCode.GDVictoria_9595StatsObjects2.length = 0;
gdjs.DerrotaCode.GDVictoria_9595StatsObjects3.length = 0;
gdjs.DerrotaCode.GDVictoria_9595PromptObjects1.length = 0;
gdjs.DerrotaCode.GDVictoria_9595PromptObjects2.length = 0;
gdjs.DerrotaCode.GDVictoria_9595PromptObjects3.length = 0;
gdjs.DerrotaCode.GDFondoSalasObjects1.length = 0;
gdjs.DerrotaCode.GDFondoSalasObjects2.length = 0;
gdjs.DerrotaCode.GDFondoSalasObjects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc1Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc1Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc1Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc2Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc2Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc2Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595AyudaObjects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595AyudaObjects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595AyudaObjects3.length = 0;
gdjs.DerrotaCode.GDFondoObjects1.length = 0;
gdjs.DerrotaCode.GDFondoObjects2.length = 0;
gdjs.DerrotaCode.GDFondoObjects3.length = 0;
gdjs.DerrotaCode.GDSolidoObjects1.length = 0;
gdjs.DerrotaCode.GDSolidoObjects2.length = 0;
gdjs.DerrotaCode.GDSolidoObjects3.length = 0;
gdjs.DerrotaCode.GDJugadorObjects1.length = 0;
gdjs.DerrotaCode.GDJugadorObjects2.length = 0;
gdjs.DerrotaCode.GDJugadorObjects3.length = 0;
gdjs.DerrotaCode.GDPuertaObjects1.length = 0;
gdjs.DerrotaCode.GDPuertaObjects2.length = 0;
gdjs.DerrotaCode.GDPuertaObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595BarraObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595BarraObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595BarraObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595NivelObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595NivelObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595NivelObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595AlmasObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595AlmasObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595AlmasObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595VidasObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595VidasObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595VidasObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595AvisoObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595AvisoObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595AvisoObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595DashObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595DashObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595DashObjects3.length = 0;
gdjs.DerrotaCode.GDJefeObjects1.length = 0;
gdjs.DerrotaCode.GDJefeObjects2.length = 0;
gdjs.DerrotaCode.GDJefeObjects3.length = 0;
gdjs.DerrotaCode.GDOndaIzqObjects1.length = 0;
gdjs.DerrotaCode.GDOndaIzqObjects2.length = 0;
gdjs.DerrotaCode.GDOndaIzqObjects3.length = 0;
gdjs.DerrotaCode.GDOndaDerObjects1.length = 0;
gdjs.DerrotaCode.GDOndaDerObjects2.length = 0;
gdjs.DerrotaCode.GDOndaDerObjects3.length = 0;
gdjs.DerrotaCode.GDGolpePalaObjects1.length = 0;
gdjs.DerrotaCode.GDGolpePalaObjects2.length = 0;
gdjs.DerrotaCode.GDGolpePalaObjects3.length = 0;
gdjs.DerrotaCode.GDAlmaObjects1.length = 0;
gdjs.DerrotaCode.GDAlmaObjects2.length = 0;
gdjs.DerrotaCode.GDAlmaObjects3.length = 0;
gdjs.DerrotaCode.GDFarolCheckpointObjects1.length = 0;
gdjs.DerrotaCode.GDFarolCheckpointObjects2.length = 0;
gdjs.DerrotaCode.GDFarolCheckpointObjects3.length = 0;
gdjs.DerrotaCode.GDPalaRecogibleObjects1.length = 0;
gdjs.DerrotaCode.GDPalaRecogibleObjects2.length = 0;
gdjs.DerrotaCode.GDPalaRecogibleObjects3.length = 0;
gdjs.DerrotaCode.GDEnemyObjects1.length = 0;
gdjs.DerrotaCode.GDEnemyObjects2.length = 0;
gdjs.DerrotaCode.GDEnemyObjects3.length = 0;
gdjs.DerrotaCode.GDPowerUpDashObjects1.length = 0;
gdjs.DerrotaCode.GDPowerUpDashObjects2.length = 0;
gdjs.DerrotaCode.GDPowerUpDashObjects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects3.length = 0;
gdjs.DerrotaCode.GDEnemyMeleeObjects1.length = 0;
gdjs.DerrotaCode.GDEnemyMeleeObjects2.length = 0;
gdjs.DerrotaCode.GDEnemyMeleeObjects3.length = 0;
gdjs.DerrotaCode.GDPinchosObjects1.length = 0;
gdjs.DerrotaCode.GDPinchosObjects2.length = 0;
gdjs.DerrotaCode.GDPinchosObjects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects3.length = 0;
gdjs.DerrotaCode.GDMiniJefeObjects1.length = 0;
gdjs.DerrotaCode.GDMiniJefeObjects2.length = 0;
gdjs.DerrotaCode.GDMiniJefeObjects3.length = 0;
gdjs.DerrotaCode.GDPowerUpRangoObjects1.length = 0;
gdjs.DerrotaCode.GDPowerUpRangoObjects2.length = 0;
gdjs.DerrotaCode.GDPowerUpRangoObjects3.length = 0;

gdjs.DerrotaCode.eventsList1(runtimeScene);
gdjs.DerrotaCode.GDFondoDerrotaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects3.length = 0;
gdjs.DerrotaCode.GDFondoTituloObjects1.length = 0;
gdjs.DerrotaCode.GDFondoTituloObjects2.length = 0;
gdjs.DerrotaCode.GDFondoTituloObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op1_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op2_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op3_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4Objects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595Op4_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.DerrotaCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.DerrotaCode.GDMenu_9595AyudaObjects3.length = 0;
gdjs.DerrotaCode.GDFondoPausaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoPausaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoPausaObjects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion1Objects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion2Objects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595Opcion3Objects3.length = 0;
gdjs.DerrotaCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.DerrotaCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.DerrotaCode.GDPausa_9595AyudaObjects3.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoDerrotaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595CausaObjects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat1Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595Stat2Objects3.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.DerrotaCode.GDDerrota_9595PromptObjects3.length = 0;
gdjs.DerrotaCode.GDFondoVictoriaObjects1.length = 0;
gdjs.DerrotaCode.GDFondoVictoriaObjects2.length = 0;
gdjs.DerrotaCode.GDFondoVictoriaObjects3.length = 0;
gdjs.DerrotaCode.GDVictoria_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDVictoria_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDVictoria_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDVictoria_9595StatsObjects1.length = 0;
gdjs.DerrotaCode.GDVictoria_9595StatsObjects2.length = 0;
gdjs.DerrotaCode.GDVictoria_9595StatsObjects3.length = 0;
gdjs.DerrotaCode.GDVictoria_9595PromptObjects1.length = 0;
gdjs.DerrotaCode.GDVictoria_9595PromptObjects2.length = 0;
gdjs.DerrotaCode.GDVictoria_9595PromptObjects3.length = 0;
gdjs.DerrotaCode.GDFondoSalasObjects1.length = 0;
gdjs.DerrotaCode.GDFondoSalasObjects2.length = 0;
gdjs.DerrotaCode.GDFondoSalasObjects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595TituloObjects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595TituloObjects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595TituloObjects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595SubObjects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595SubObjects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595SubObjects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion1Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion2Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion3Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion4Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion5Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Opcion6Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc1Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc1Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc1Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc2Objects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc2Objects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595Desc2Objects3.length = 0;
gdjs.DerrotaCode.GDSalas_9595AyudaObjects1.length = 0;
gdjs.DerrotaCode.GDSalas_9595AyudaObjects2.length = 0;
gdjs.DerrotaCode.GDSalas_9595AyudaObjects3.length = 0;
gdjs.DerrotaCode.GDFondoObjects1.length = 0;
gdjs.DerrotaCode.GDFondoObjects2.length = 0;
gdjs.DerrotaCode.GDFondoObjects3.length = 0;
gdjs.DerrotaCode.GDSolidoObjects1.length = 0;
gdjs.DerrotaCode.GDSolidoObjects2.length = 0;
gdjs.DerrotaCode.GDSolidoObjects3.length = 0;
gdjs.DerrotaCode.GDJugadorObjects1.length = 0;
gdjs.DerrotaCode.GDJugadorObjects2.length = 0;
gdjs.DerrotaCode.GDJugadorObjects3.length = 0;
gdjs.DerrotaCode.GDPuertaObjects1.length = 0;
gdjs.DerrotaCode.GDPuertaObjects2.length = 0;
gdjs.DerrotaCode.GDPuertaObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595BarraObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595BarraObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595BarraObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595NivelObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595NivelObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595NivelObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595AlmasObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595AlmasObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595AlmasObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595VidasObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595VidasObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595VidasObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595AvisoObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595AvisoObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595AvisoObjects3.length = 0;
gdjs.DerrotaCode.GDHUD_9595DashObjects1.length = 0;
gdjs.DerrotaCode.GDHUD_9595DashObjects2.length = 0;
gdjs.DerrotaCode.GDHUD_9595DashObjects3.length = 0;
gdjs.DerrotaCode.GDJefeObjects1.length = 0;
gdjs.DerrotaCode.GDJefeObjects2.length = 0;
gdjs.DerrotaCode.GDJefeObjects3.length = 0;
gdjs.DerrotaCode.GDOndaIzqObjects1.length = 0;
gdjs.DerrotaCode.GDOndaIzqObjects2.length = 0;
gdjs.DerrotaCode.GDOndaIzqObjects3.length = 0;
gdjs.DerrotaCode.GDOndaDerObjects1.length = 0;
gdjs.DerrotaCode.GDOndaDerObjects2.length = 0;
gdjs.DerrotaCode.GDOndaDerObjects3.length = 0;
gdjs.DerrotaCode.GDGolpePalaObjects1.length = 0;
gdjs.DerrotaCode.GDGolpePalaObjects2.length = 0;
gdjs.DerrotaCode.GDGolpePalaObjects3.length = 0;
gdjs.DerrotaCode.GDAlmaObjects1.length = 0;
gdjs.DerrotaCode.GDAlmaObjects2.length = 0;
gdjs.DerrotaCode.GDAlmaObjects3.length = 0;
gdjs.DerrotaCode.GDFarolCheckpointObjects1.length = 0;
gdjs.DerrotaCode.GDFarolCheckpointObjects2.length = 0;
gdjs.DerrotaCode.GDFarolCheckpointObjects3.length = 0;
gdjs.DerrotaCode.GDPalaRecogibleObjects1.length = 0;
gdjs.DerrotaCode.GDPalaRecogibleObjects2.length = 0;
gdjs.DerrotaCode.GDPalaRecogibleObjects3.length = 0;
gdjs.DerrotaCode.GDEnemyObjects1.length = 0;
gdjs.DerrotaCode.GDEnemyObjects2.length = 0;
gdjs.DerrotaCode.GDEnemyObjects3.length = 0;
gdjs.DerrotaCode.GDPowerUpDashObjects1.length = 0;
gdjs.DerrotaCode.GDPowerUpDashObjects2.length = 0;
gdjs.DerrotaCode.GDPowerUpDashObjects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95951Objects3.length = 0;
gdjs.DerrotaCode.GDEnemyMeleeObjects1.length = 0;
gdjs.DerrotaCode.GDEnemyMeleeObjects2.length = 0;
gdjs.DerrotaCode.GDEnemyMeleeObjects3.length = 0;
gdjs.DerrotaCode.GDPinchosObjects1.length = 0;
gdjs.DerrotaCode.GDPinchosObjects2.length = 0;
gdjs.DerrotaCode.GDPinchosObjects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95952Objects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95953Objects3.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.DerrotaCode.GDPlataformaMovil_95954Objects3.length = 0;
gdjs.DerrotaCode.GDMiniJefeObjects1.length = 0;
gdjs.DerrotaCode.GDMiniJefeObjects2.length = 0;
gdjs.DerrotaCode.GDMiniJefeObjects3.length = 0;
gdjs.DerrotaCode.GDPowerUpRangoObjects1.length = 0;
gdjs.DerrotaCode.GDPowerUpRangoObjects2.length = 0;
gdjs.DerrotaCode.GDPowerUpRangoObjects3.length = 0;


return;

}

gdjs['DerrotaCode'] = gdjs.DerrotaCode;
