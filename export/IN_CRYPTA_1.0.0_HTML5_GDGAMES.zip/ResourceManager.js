//# sourceMappingURL=ResourceManager.js.map
