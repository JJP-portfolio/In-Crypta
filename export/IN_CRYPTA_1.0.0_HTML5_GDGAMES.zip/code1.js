gdjs.PausaCode = {};
gdjs.PausaCode.localVariables = [];
gdjs.PausaCode.idToCallbackMap = new Map();
gdjs.PausaCode.GDFondoPausaObjects1= [];
gdjs.PausaCode.GDFondoPausaObjects2= [];
gdjs.PausaCode.GDPausa_9595TituloObjects1= [];
gdjs.PausaCode.GDPausa_9595TituloObjects2= [];
gdjs.PausaCode.GDPausa_9595SubObjects1= [];
gdjs.PausaCode.GDPausa_9595SubObjects2= [];
gdjs.PausaCode.GDPausa_9595Opcion1Objects1= [];
gdjs.PausaCode.GDPausa_9595Opcion1Objects2= [];
gdjs.PausaCode.GDPausa_9595Opcion2Objects1= [];
gdjs.PausaCode.GDPausa_9595Opcion2Objects2= [];
gdjs.PausaCode.GDPausa_9595Opcion3Objects1= [];
gdjs.PausaCode.GDPausa_9595Opcion3Objects2= [];
gdjs.PausaCode.GDPausa_9595AyudaObjects1= [];
gdjs.PausaCode.GDPausa_9595AyudaObjects2= [];
gdjs.PausaCode.GDFondoTituloObjects1= [];
gdjs.PausaCode.GDFondoTituloObjects2= [];
gdjs.PausaCode.GDMenu_9595TituloObjects1= [];
gdjs.PausaCode.GDMenu_9595TituloObjects2= [];
gdjs.PausaCode.GDMenu_9595SubObjects1= [];
gdjs.PausaCode.GDMenu_9595SubObjects2= [];
gdjs.PausaCode.GDMenu_9595Op1Objects1= [];
gdjs.PausaCode.GDMenu_9595Op1Objects2= [];
gdjs.PausaCode.GDMenu_9595Op1_9595SubObjects1= [];
gdjs.PausaCode.GDMenu_9595Op1_9595SubObjects2= [];
gdjs.PausaCode.GDMenu_9595Op2Objects1= [];
gdjs.PausaCode.GDMenu_9595Op2Objects2= [];
gdjs.PausaCode.GDMenu_9595Op2_9595SubObjects1= [];
gdjs.PausaCode.GDMenu_9595Op2_9595SubObjects2= [];
gdjs.PausaCode.GDMenu_9595Op3Objects1= [];
gdjs.PausaCode.GDMenu_9595Op3Objects2= [];
gdjs.PausaCode.GDMenu_9595Op3_9595SubObjects1= [];
gdjs.PausaCode.GDMenu_9595Op3_9595SubObjects2= [];
gdjs.PausaCode.GDMenu_9595Op4Objects1= [];
gdjs.PausaCode.GDMenu_9595Op4Objects2= [];
gdjs.PausaCode.GDMenu_9595Op4_9595SubObjects1= [];
gdjs.PausaCode.GDMenu_9595Op4_9595SubObjects2= [];
gdjs.PausaCode.GDMenu_9595AyudaObjects1= [];
gdjs.PausaCode.GDMenu_9595AyudaObjects2= [];
gdjs.PausaCode.GDFondoPausaObjects1= [];
gdjs.PausaCode.GDFondoPausaObjects2= [];
gdjs.PausaCode.GDPausa_9595TituloObjects1= [];
gdjs.PausaCode.GDPausa_9595TituloObjects2= [];
gdjs.PausaCode.GDPausa_9595SubObjects1= [];
gdjs.PausaCode.GDPausa_9595SubObjects2= [];
gdjs.PausaCode.GDPausa_9595Opcion1Objects1= [];
gdjs.PausaCode.GDPausa_9595Opcion1Objects2= [];
gdjs.PausaCode.GDPausa_9595Opcion2Objects1= [];
gdjs.PausaCode.GDPausa_9595Opcion2Objects2= [];
gdjs.PausaCode.GDPausa_9595Opcion3Objects1= [];
gdjs.PausaCode.GDPausa_9595Opcion3Objects2= [];
gdjs.PausaCode.GDPausa_9595AyudaObjects1= [];
gdjs.PausaCode.GDPausa_9595AyudaObjects2= [];
gdjs.PausaCode.GDFondoDerrotaObjects1= [];
gdjs.PausaCode.GDFondoDerrotaObjects2= [];
gdjs.PausaCode.GDDerrota_9595TituloObjects1= [];
gdjs.PausaCode.GDDerrota_9595TituloObjects2= [];
gdjs.PausaCode.GDDerrota_9595CausaObjects1= [];
gdjs.PausaCode.GDDerrota_9595CausaObjects2= [];
gdjs.PausaCode.GDDerrota_9595Stat1Objects1= [];
gdjs.PausaCode.GDDerrota_9595Stat1Objects2= [];
gdjs.PausaCode.GDDerrota_9595Stat2Objects1= [];
gdjs.PausaCode.GDDerrota_9595Stat2Objects2= [];
gdjs.PausaCode.GDDerrota_9595PromptObjects1= [];
gdjs.PausaCode.GDDerrota_9595PromptObjects2= [];
gdjs.PausaCode.GDFondoVictoriaObjects1= [];
gdjs.PausaCode.GDFondoVictoriaObjects2= [];
gdjs.PausaCode.GDVictoria_9595TituloObjects1= [];
gdjs.PausaCode.GDVictoria_9595TituloObjects2= [];
gdjs.PausaCode.GDVictoria_9595StatsObjects1= [];
gdjs.PausaCode.GDVictoria_9595StatsObjects2= [];
gdjs.PausaCode.GDVictoria_9595PromptObjects1= [];
gdjs.PausaCode.GDVictoria_9595PromptObjects2= [];
gdjs.PausaCode.GDFondoSalasObjects1= [];
gdjs.PausaCode.GDFondoSalasObjects2= [];
gdjs.PausaCode.GDSalas_9595TituloObjects1= [];
gdjs.PausaCode.GDSalas_9595TituloObjects2= [];
gdjs.PausaCode.GDSalas_9595SubObjects1= [];
gdjs.PausaCode.GDSalas_9595SubObjects2= [];
gdjs.PausaCode.GDSalas_9595Opcion1Objects1= [];
gdjs.PausaCode.GDSalas_9595Opcion1Objects2= [];
gdjs.PausaCode.GDSalas_9595Opcion2Objects1= [];
gdjs.PausaCode.GDSalas_9595Opcion2Objects2= [];
gdjs.PausaCode.GDSalas_9595Opcion3Objects1= [];
gdjs.PausaCode.GDSalas_9595Opcion3Objects2= [];
gdjs.PausaCode.GDSalas_9595Opcion4Objects1= [];
gdjs.PausaCode.GDSalas_9595Opcion4Objects2= [];
gdjs.PausaCode.GDSalas_9595Opcion5Objects1= [];
gdjs.PausaCode.GDSalas_9595Opcion5Objects2= [];
gdjs.PausaCode.GDSalas_9595Opcion6Objects1= [];
gdjs.PausaCode.GDSalas_9595Opcion6Objects2= [];
gdjs.PausaCode.GDSalas_9595Desc1Objects1= [];
gdjs.PausaCode.GDSalas_9595Desc1Objects2= [];
gdjs.PausaCode.GDSalas_9595Desc2Objects1= [];
gdjs.PausaCode.GDSalas_9595Desc2Objects2= [];
gdjs.PausaCode.GDSalas_9595AyudaObjects1= [];
gdjs.PausaCode.GDSalas_9595AyudaObjects2= [];
gdjs.PausaCode.GDFondoObjects1= [];
gdjs.PausaCode.GDFondoObjects2= [];
gdjs.PausaCode.GDSolidoObjects1= [];
gdjs.PausaCode.GDSolidoObjects2= [];
gdjs.PausaCode.GDJugadorObjects1= [];
gdjs.PausaCode.GDJugadorObjects2= [];
gdjs.PausaCode.GDPuertaObjects1= [];
gdjs.PausaCode.GDPuertaObjects2= [];
gdjs.PausaCode.GDHUD_9595BarraObjects1= [];
gdjs.PausaCode.GDHUD_9595BarraObjects2= [];
gdjs.PausaCode.GDHUD_9595NivelObjects1= [];
gdjs.PausaCode.GDHUD_9595NivelObjects2= [];
gdjs.PausaCode.GDHUD_9595AlmasObjects1= [];
gdjs.PausaCode.GDHUD_9595AlmasObjects2= [];
gdjs.PausaCode.GDHUD_9595VidasObjects1= [];
gdjs.PausaCode.GDHUD_9595VidasObjects2= [];
gdjs.PausaCode.GDHUD_9595AvisoObjects1= [];
gdjs.PausaCode.GDHUD_9595AvisoObjects2= [];
gdjs.PausaCode.GDHUD_9595DashObjects1= [];
gdjs.PausaCode.GDHUD_9595DashObjects2= [];
gdjs.PausaCode.GDJefeObjects1= [];
gdjs.PausaCode.GDJefeObjects2= [];
gdjs.PausaCode.GDOndaIzqObjects1= [];
gdjs.PausaCode.GDOndaIzqObjects2= [];
gdjs.PausaCode.GDOndaDerObjects1= [];
gdjs.PausaCode.GDOndaDerObjects2= [];
gdjs.PausaCode.GDGolpePalaObjects1= [];
gdjs.PausaCode.GDGolpePalaObjects2= [];
gdjs.PausaCode.GDAlmaObjects1= [];
gdjs.PausaCode.GDAlmaObjects2= [];
gdjs.PausaCode.GDFarolCheckpointObjects1= [];
gdjs.PausaCode.GDFarolCheckpointObjects2= [];
gdjs.PausaCode.GDPalaRecogibleObjects1= [];
gdjs.PausaCode.GDPalaRecogibleObjects2= [];
gdjs.PausaCode.GDEnemyObjects1= [];
gdjs.PausaCode.GDEnemyObjects2= [];
gdjs.PausaCode.GDPowerUpDashObjects1= [];
gdjs.PausaCode.GDPowerUpDashObjects2= [];
gdjs.PausaCode.GDPlataformaMovil_95951Objects1= [];
gdjs.PausaCode.GDPlataformaMovil_95951Objects2= [];
gdjs.PausaCode.GDEnemyMeleeObjects1= [];
gdjs.PausaCode.GDEnemyMeleeObjects2= [];
gdjs.PausaCode.GDPinchosObjects1= [];
gdjs.PausaCode.GDPinchosObjects2= [];
gdjs.PausaCode.GDPlataformaMovil_95952Objects1= [];
gdjs.PausaCode.GDPlataformaMovil_95952Objects2= [];
gdjs.PausaCode.GDPlataformaMovil_95953Objects1= [];
gdjs.PausaCode.GDPlataformaMovil_95953Objects2= [];
gdjs.PausaCode.GDPlataformaMovil_95954Objects1= [];
gdjs.PausaCode.GDPlataformaMovil_95954Objects2= [];
gdjs.PausaCode.GDMiniJefeObjects1= [];
gdjs.PausaCode.GDMiniJefeObjects2= [];
gdjs.PausaCode.GDPowerUpRangoObjects1= [];
gdjs.PausaCode.GDPowerUpRangoObjects2= [];


gdjs.PausaCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(512);
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(288);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.25, "", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 512, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 288, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "UI", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 640, "UI", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 360, "UI", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion1"), gdjs.PausaCode.GDPausa_9595Opcion1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion2"), gdjs.PausaCode.GDPausa_9595Opcion2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion3"), gdjs.PausaCode.GDPausa_9595Opcion3Objects1);
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion1Objects1[i].setString(">> CONTINUAR <<");
}
}
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion2Objects1[i].setString("REINICIAR NIVEL");
}
}
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion3Objects1[i].setString("VOLVER AL TÍTULO");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion1"), gdjs.PausaCode.GDPausa_9595Opcion1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion2"), gdjs.PausaCode.GDPausa_9595Opcion2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion3"), gdjs.PausaCode.GDPausa_9595Opcion3Objects1);
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion1Objects1[i].setString("CONTINUAR");
}
}
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion2Objects1[i].setString(">> REINICIAR NIVEL <<");
}
}
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion3Objects1[i].setString("VOLVER AL TÍTULO");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion1"), gdjs.PausaCode.GDPausa_9595Opcion1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion2"), gdjs.PausaCode.GDPausa_9595Opcion2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pausa_Opcion3"), gdjs.PausaCode.GDPausa_9595Opcion3Objects1);
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion1Objects1[i].setString("CONTINUAR");
}
}
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion2Objects1[i].setString("REINICIAR NIVEL");
}
}
{for(var i = 0, len = gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length ;i < len;++i) {
    gdjs.PausaCode.GDPausa_9595Opcion3Objects1[i].setString(">> VOLVER AL TÍTULO <<");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() < 3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(1);
}
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Titulo", true);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
}

}


};

gdjs.PausaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PausaCode.GDFondoPausaObjects1.length = 0;
gdjs.PausaCode.GDFondoPausaObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoTituloObjects1.length = 0;
gdjs.PausaCode.GDFondoTituloObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoPausaObjects1.length = 0;
gdjs.PausaCode.GDFondoPausaObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoDerrotaObjects1.length = 0;
gdjs.PausaCode.GDFondoDerrotaObjects2.length = 0;
gdjs.PausaCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.PausaCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.PausaCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.PausaCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.PausaCode.GDFondoVictoriaObjects1.length = 0;
gdjs.PausaCode.GDFondoVictoriaObjects2.length = 0;
gdjs.PausaCode.GDVictoria_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDVictoria_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDVictoria_9595StatsObjects1.length = 0;
gdjs.PausaCode.GDVictoria_9595StatsObjects2.length = 0;
gdjs.PausaCode.GDVictoria_9595PromptObjects1.length = 0;
gdjs.PausaCode.GDVictoria_9595PromptObjects2.length = 0;
gdjs.PausaCode.GDFondoSalasObjects1.length = 0;
gdjs.PausaCode.GDFondoSalasObjects2.length = 0;
gdjs.PausaCode.GDSalas_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDSalas_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDSalas_9595SubObjects1.length = 0;
gdjs.PausaCode.GDSalas_9595SubObjects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Desc1Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Desc1Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Desc2Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Desc2Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDSalas_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoObjects1.length = 0;
gdjs.PausaCode.GDFondoObjects2.length = 0;
gdjs.PausaCode.GDSolidoObjects1.length = 0;
gdjs.PausaCode.GDSolidoObjects2.length = 0;
gdjs.PausaCode.GDJugadorObjects1.length = 0;
gdjs.PausaCode.GDJugadorObjects2.length = 0;
gdjs.PausaCode.GDPuertaObjects1.length = 0;
gdjs.PausaCode.GDPuertaObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595BarraObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595BarraObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595NivelObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595NivelObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595AlmasObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595AlmasObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595VidasObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595VidasObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595AvisoObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595AvisoObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595DashObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595DashObjects2.length = 0;
gdjs.PausaCode.GDJefeObjects1.length = 0;
gdjs.PausaCode.GDJefeObjects2.length = 0;
gdjs.PausaCode.GDOndaIzqObjects1.length = 0;
gdjs.PausaCode.GDOndaIzqObjects2.length = 0;
gdjs.PausaCode.GDOndaDerObjects1.length = 0;
gdjs.PausaCode.GDOndaDerObjects2.length = 0;
gdjs.PausaCode.GDGolpePalaObjects1.length = 0;
gdjs.PausaCode.GDGolpePalaObjects2.length = 0;
gdjs.PausaCode.GDAlmaObjects1.length = 0;
gdjs.PausaCode.GDAlmaObjects2.length = 0;
gdjs.PausaCode.GDFarolCheckpointObjects1.length = 0;
gdjs.PausaCode.GDFarolCheckpointObjects2.length = 0;
gdjs.PausaCode.GDPalaRecogibleObjects1.length = 0;
gdjs.PausaCode.GDPalaRecogibleObjects2.length = 0;
gdjs.PausaCode.GDEnemyObjects1.length = 0;
gdjs.PausaCode.GDEnemyObjects2.length = 0;
gdjs.PausaCode.GDPowerUpDashObjects1.length = 0;
gdjs.PausaCode.GDPowerUpDashObjects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.PausaCode.GDEnemyMeleeObjects1.length = 0;
gdjs.PausaCode.GDEnemyMeleeObjects2.length = 0;
gdjs.PausaCode.GDPinchosObjects1.length = 0;
gdjs.PausaCode.GDPinchosObjects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.PausaCode.GDMiniJefeObjects1.length = 0;
gdjs.PausaCode.GDMiniJefeObjects2.length = 0;
gdjs.PausaCode.GDPowerUpRangoObjects1.length = 0;
gdjs.PausaCode.GDPowerUpRangoObjects2.length = 0;

gdjs.PausaCode.eventsList0(runtimeScene);
gdjs.PausaCode.GDFondoPausaObjects1.length = 0;
gdjs.PausaCode.GDFondoPausaObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoTituloObjects1.length = 0;
gdjs.PausaCode.GDFondoTituloObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.PausaCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.PausaCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoPausaObjects1.length = 0;
gdjs.PausaCode.GDFondoPausaObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595SubObjects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.PausaCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoDerrotaObjects1.length = 0;
gdjs.PausaCode.GDFondoDerrotaObjects2.length = 0;
gdjs.PausaCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.PausaCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.PausaCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.PausaCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.PausaCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.PausaCode.GDFondoVictoriaObjects1.length = 0;
gdjs.PausaCode.GDFondoVictoriaObjects2.length = 0;
gdjs.PausaCode.GDVictoria_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDVictoria_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDVictoria_9595StatsObjects1.length = 0;
gdjs.PausaCode.GDVictoria_9595StatsObjects2.length = 0;
gdjs.PausaCode.GDVictoria_9595PromptObjects1.length = 0;
gdjs.PausaCode.GDVictoria_9595PromptObjects2.length = 0;
gdjs.PausaCode.GDFondoSalasObjects1.length = 0;
gdjs.PausaCode.GDFondoSalasObjects2.length = 0;
gdjs.PausaCode.GDSalas_9595TituloObjects1.length = 0;
gdjs.PausaCode.GDSalas_9595TituloObjects2.length = 0;
gdjs.PausaCode.GDSalas_9595SubObjects1.length = 0;
gdjs.PausaCode.GDSalas_9595SubObjects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Desc1Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Desc1Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595Desc2Objects1.length = 0;
gdjs.PausaCode.GDSalas_9595Desc2Objects2.length = 0;
gdjs.PausaCode.GDSalas_9595AyudaObjects1.length = 0;
gdjs.PausaCode.GDSalas_9595AyudaObjects2.length = 0;
gdjs.PausaCode.GDFondoObjects1.length = 0;
gdjs.PausaCode.GDFondoObjects2.length = 0;
gdjs.PausaCode.GDSolidoObjects1.length = 0;
gdjs.PausaCode.GDSolidoObjects2.length = 0;
gdjs.PausaCode.GDJugadorObjects1.length = 0;
gdjs.PausaCode.GDJugadorObjects2.length = 0;
gdjs.PausaCode.GDPuertaObjects1.length = 0;
gdjs.PausaCode.GDPuertaObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595BarraObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595BarraObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595NivelObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595NivelObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595AlmasObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595AlmasObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595VidasObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595VidasObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595AvisoObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595AvisoObjects2.length = 0;
gdjs.PausaCode.GDHUD_9595DashObjects1.length = 0;
gdjs.PausaCode.GDHUD_9595DashObjects2.length = 0;
gdjs.PausaCode.GDJefeObjects1.length = 0;
gdjs.PausaCode.GDJefeObjects2.length = 0;
gdjs.PausaCode.GDOndaIzqObjects1.length = 0;
gdjs.PausaCode.GDOndaIzqObjects2.length = 0;
gdjs.PausaCode.GDOndaDerObjects1.length = 0;
gdjs.PausaCode.GDOndaDerObjects2.length = 0;
gdjs.PausaCode.GDGolpePalaObjects1.length = 0;
gdjs.PausaCode.GDGolpePalaObjects2.length = 0;
gdjs.PausaCode.GDAlmaObjects1.length = 0;
gdjs.PausaCode.GDAlmaObjects2.length = 0;
gdjs.PausaCode.GDFarolCheckpointObjects1.length = 0;
gdjs.PausaCode.GDFarolCheckpointObjects2.length = 0;
gdjs.PausaCode.GDPalaRecogibleObjects1.length = 0;
gdjs.PausaCode.GDPalaRecogibleObjects2.length = 0;
gdjs.PausaCode.GDEnemyObjects1.length = 0;
gdjs.PausaCode.GDEnemyObjects2.length = 0;
gdjs.PausaCode.GDPowerUpDashObjects1.length = 0;
gdjs.PausaCode.GDPowerUpDashObjects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.PausaCode.GDEnemyMeleeObjects1.length = 0;
gdjs.PausaCode.GDEnemyMeleeObjects2.length = 0;
gdjs.PausaCode.GDPinchosObjects1.length = 0;
gdjs.PausaCode.GDPinchosObjects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.PausaCode.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.PausaCode.GDMiniJefeObjects1.length = 0;
gdjs.PausaCode.GDMiniJefeObjects2.length = 0;
gdjs.PausaCode.GDPowerUpRangoObjects1.length = 0;
gdjs.PausaCode.GDPowerUpRangoObjects2.length = 0;


return;

}

gdjs['PausaCode'] = gdjs.PausaCode;
