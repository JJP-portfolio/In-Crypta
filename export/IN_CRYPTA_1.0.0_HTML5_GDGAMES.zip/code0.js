gdjs.TituloCode = {};
gdjs.TituloCode.localVariables = [];
gdjs.TituloCode.idToCallbackMap = new Map();
gdjs.TituloCode.GDFondoTituloObjects1= [];
gdjs.TituloCode.GDFondoTituloObjects2= [];
gdjs.TituloCode.GDMenu_9595TituloObjects1= [];
gdjs.TituloCode.GDMenu_9595TituloObjects2= [];
gdjs.TituloCode.GDMenu_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op1Objects1= [];
gdjs.TituloCode.GDMenu_9595Op1Objects2= [];
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op2Objects1= [];
gdjs.TituloCode.GDMenu_9595Op2Objects2= [];
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op3Objects1= [];
gdjs.TituloCode.GDMenu_9595Op3Objects2= [];
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op4Objects1= [];
gdjs.TituloCode.GDMenu_9595Op4Objects2= [];
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595AyudaObjects1= [];
gdjs.TituloCode.GDMenu_9595AyudaObjects2= [];
gdjs.TituloCode.GDFondoTituloObjects1= [];
gdjs.TituloCode.GDFondoTituloObjects2= [];
gdjs.TituloCode.GDMenu_9595TituloObjects1= [];
gdjs.TituloCode.GDMenu_9595TituloObjects2= [];
gdjs.TituloCode.GDMenu_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op1Objects1= [];
gdjs.TituloCode.GDMenu_9595Op1Objects2= [];
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op2Objects1= [];
gdjs.TituloCode.GDMenu_9595Op2Objects2= [];
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op3Objects1= [];
gdjs.TituloCode.GDMenu_9595Op3Objects2= [];
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595Op4Objects1= [];
gdjs.TituloCode.GDMenu_9595Op4Objects2= [];
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects1= [];
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects2= [];
gdjs.TituloCode.GDMenu_9595AyudaObjects1= [];
gdjs.TituloCode.GDMenu_9595AyudaObjects2= [];
gdjs.TituloCode.GDFondoPausaObjects1= [];
gdjs.TituloCode.GDFondoPausaObjects2= [];
gdjs.TituloCode.GDPausa_9595TituloObjects1= [];
gdjs.TituloCode.GDPausa_9595TituloObjects2= [];
gdjs.TituloCode.GDPausa_9595SubObjects1= [];
gdjs.TituloCode.GDPausa_9595SubObjects2= [];
gdjs.TituloCode.GDPausa_9595Opcion1Objects1= [];
gdjs.TituloCode.GDPausa_9595Opcion1Objects2= [];
gdjs.TituloCode.GDPausa_9595Opcion2Objects1= [];
gdjs.TituloCode.GDPausa_9595Opcion2Objects2= [];
gdjs.TituloCode.GDPausa_9595Opcion3Objects1= [];
gdjs.TituloCode.GDPausa_9595Opcion3Objects2= [];
gdjs.TituloCode.GDPausa_9595AyudaObjects1= [];
gdjs.TituloCode.GDPausa_9595AyudaObjects2= [];
gdjs.TituloCode.GDFondoDerrotaObjects1= [];
gdjs.TituloCode.GDFondoDerrotaObjects2= [];
gdjs.TituloCode.GDDerrota_9595TituloObjects1= [];
gdjs.TituloCode.GDDerrota_9595TituloObjects2= [];
gdjs.TituloCode.GDDerrota_9595CausaObjects1= [];
gdjs.TituloCode.GDDerrota_9595CausaObjects2= [];
gdjs.TituloCode.GDDerrota_9595Stat1Objects1= [];
gdjs.TituloCode.GDDerrota_9595Stat1Objects2= [];
gdjs.TituloCode.GDDerrota_9595Stat2Objects1= [];
gdjs.TituloCode.GDDerrota_9595Stat2Objects2= [];
gdjs.TituloCode.GDDerrota_9595PromptObjects1= [];
gdjs.TituloCode.GDDerrota_9595PromptObjects2= [];
gdjs.TituloCode.GDFondoVictoriaObjects1= [];
gdjs.TituloCode.GDFondoVictoriaObjects2= [];
gdjs.TituloCode.GDVictoria_9595TituloObjects1= [];
gdjs.TituloCode.GDVictoria_9595TituloObjects2= [];
gdjs.TituloCode.GDVictoria_9595StatsObjects1= [];
gdjs.TituloCode.GDVictoria_9595StatsObjects2= [];
gdjs.TituloCode.GDVictoria_9595PromptObjects1= [];
gdjs.TituloCode.GDVictoria_9595PromptObjects2= [];
gdjs.TituloCode.GDFondoSalasObjects1= [];
gdjs.TituloCode.GDFondoSalasObjects2= [];
gdjs.TituloCode.GDSalas_9595TituloObjects1= [];
gdjs.TituloCode.GDSalas_9595TituloObjects2= [];
gdjs.TituloCode.GDSalas_9595SubObjects1= [];
gdjs.TituloCode.GDSalas_9595SubObjects2= [];
gdjs.TituloCode.GDSalas_9595Opcion1Objects1= [];
gdjs.TituloCode.GDSalas_9595Opcion1Objects2= [];
gdjs.TituloCode.GDSalas_9595Opcion2Objects1= [];
gdjs.TituloCode.GDSalas_9595Opcion2Objects2= [];
gdjs.TituloCode.GDSalas_9595Opcion3Objects1= [];
gdjs.TituloCode.GDSalas_9595Opcion3Objects2= [];
gdjs.TituloCode.GDSalas_9595Opcion4Objects1= [];
gdjs.TituloCode.GDSalas_9595Opcion4Objects2= [];
gdjs.TituloCode.GDSalas_9595Opcion5Objects1= [];
gdjs.TituloCode.GDSalas_9595Opcion5Objects2= [];
gdjs.TituloCode.GDSalas_9595Opcion6Objects1= [];
gdjs.TituloCode.GDSalas_9595Opcion6Objects2= [];
gdjs.TituloCode.GDSalas_9595Desc1Objects1= [];
gdjs.TituloCode.GDSalas_9595Desc1Objects2= [];
gdjs.TituloCode.GDSalas_9595Desc2Objects1= [];
gdjs.TituloCode.GDSalas_9595Desc2Objects2= [];
gdjs.TituloCode.GDSalas_9595AyudaObjects1= [];
gdjs.TituloCode.GDSalas_9595AyudaObjects2= [];
gdjs.TituloCode.GDFondoObjects1= [];
gdjs.TituloCode.GDFondoObjects2= [];
gdjs.TituloCode.GDSolidoObjects1= [];
gdjs.TituloCode.GDSolidoObjects2= [];
gdjs.TituloCode.GDJugadorObjects1= [];
gdjs.TituloCode.GDJugadorObjects2= [];
gdjs.TituloCode.GDPuertaObjects1= [];
gdjs.TituloCode.GDPuertaObjects2= [];
gdjs.TituloCode.GDHUD_9595BarraObjects1= [];
gdjs.TituloCode.GDHUD_9595BarraObjects2= [];
gdjs.TituloCode.GDHUD_9595NivelObjects1= [];
gdjs.TituloCode.GDHUD_9595NivelObjects2= [];
gdjs.TituloCode.GDHUD_9595AlmasObjects1= [];
gdjs.TituloCode.GDHUD_9595AlmasObjects2= [];
gdjs.TituloCode.GDHUD_9595VidasObjects1= [];
gdjs.TituloCode.GDHUD_9595VidasObjects2= [];
gdjs.TituloCode.GDHUD_9595AvisoObjects1= [];
gdjs.TituloCode.GDHUD_9595AvisoObjects2= [];
gdjs.TituloCode.GDHUD_9595DashObjects1= [];
gdjs.TituloCode.GDHUD_9595DashObjects2= [];
gdjs.TituloCode.GDJefeObjects1= [];
gdjs.TituloCode.GDJefeObjects2= [];
gdjs.TituloCode.GDOndaIzqObjects1= [];
gdjs.TituloCode.GDOndaIzqObjects2= [];
gdjs.TituloCode.GDOndaDerObjects1= [];
gdjs.TituloCode.GDOndaDerObjects2= [];
gdjs.TituloCode.GDGolpePalaObjects1= [];
gdjs.TituloCode.GDGolpePalaObjects2= [];
gdjs.TituloCode.GDAlmaObjects1= [];
gdjs.TituloCode.GDAlmaObjects2= [];
gdjs.TituloCode.GDFarolCheckpointObjects1= [];
gdjs.TituloCode.GDFarolCheckpointObjects2= [];
gdjs.TituloCode.GDPalaRecogibleObjects1= [];
gdjs.TituloCode.GDPalaRecogibleObjects2= [];
gdjs.TituloCode.GDEnemyObjects1= [];
gdjs.TituloCode.GDEnemyObjects2= [];
gdjs.TituloCode.GDPowerUpDashObjects1= [];
gdjs.TituloCode.GDPowerUpDashObjects2= [];
gdjs.TituloCode.GDPlataformaMovil_95951Objects1= [];
gdjs.TituloCode.GDPlataformaMovil_95951Objects2= [];
gdjs.TituloCode.GDEnemyMeleeObjects1= [];
gdjs.TituloCode.GDEnemyMeleeObjects2= [];
gdjs.TituloCode.GDPinchosObjects1= [];
gdjs.TituloCode.GDPinchosObjects2= [];
gdjs.TituloCode.GDPlataformaMovil_95952Objects1= [];
gdjs.TituloCode.GDPlataformaMovil_95952Objects2= [];
gdjs.TituloCode.GDPlataformaMovil_95953Objects1= [];
gdjs.TituloCode.GDPlataformaMovil_95953Objects2= [];
gdjs.TituloCode.GDPlataformaMovil_95954Objects1= [];
gdjs.TituloCode.GDPlataformaMovil_95954Objects2= [];
gdjs.TituloCode.GDMiniJefeObjects1= [];
gdjs.TituloCode.GDMiniJefeObjects2= [];
gdjs.TituloCode.GDPowerUpRangoObjects1= [];
gdjs.TituloCode.GDPowerUpRangoObjects2= [];


gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op1Objects1Objects = Hashtable.newFrom({"Menu_Op1": gdjs.TituloCode.GDMenu_9595Op1Objects1});
gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op2Objects1Objects = Hashtable.newFrom({"Menu_Op2": gdjs.TituloCode.GDMenu_9595Op2Objects1});
gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op3Objects1Objects = Hashtable.newFrom({"Menu_Op3": gdjs.TituloCode.GDMenu_9595Op3Objects1});
gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op4Objects1Objects = Hashtable.newFrom({"Menu_Op4": gdjs.TituloCode.GDMenu_9595Op4Objects1});
gdjs.TituloCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(512);
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(288);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.25, "", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 512, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 288, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "UI", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 640, "UI", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 360, "UI", 0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menu_Op1"), gdjs.TituloCode.GDMenu_9595Op1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op2"), gdjs.TituloCode.GDMenu_9595Op2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op3"), gdjs.TituloCode.GDMenu_9595Op3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op4"), gdjs.TituloCode.GDMenu_9595Op4Objects1);
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op1Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op1Objects1[i].setString(">> 1 · JUGAR <<");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op2Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op2Objects1[i].setString("2 · SELECCIÓN DE NIVEL");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op3Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op3Objects1[i].setString("3 · TUTORIAL");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op4Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op4Objects1[i].setString("4 · SALAS DE PRUEBA");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menu_Op1"), gdjs.TituloCode.GDMenu_9595Op1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op2"), gdjs.TituloCode.GDMenu_9595Op2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op3"), gdjs.TituloCode.GDMenu_9595Op3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op4"), gdjs.TituloCode.GDMenu_9595Op4Objects1);
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op1Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op1Objects1[i].setString("1 · JUGAR");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op2Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op2Objects1[i].setString(">> 2 · SELECCIÓN DE NIVEL <<");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op3Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op3Objects1[i].setString("3 · TUTORIAL");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op4Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op4Objects1[i].setString("4 · SALAS DE PRUEBA");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menu_Op1"), gdjs.TituloCode.GDMenu_9595Op1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op2"), gdjs.TituloCode.GDMenu_9595Op2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op3"), gdjs.TituloCode.GDMenu_9595Op3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op4"), gdjs.TituloCode.GDMenu_9595Op4Objects1);
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op1Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op1Objects1[i].setString("1 · JUGAR");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op2Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op2Objects1[i].setString("2 · SELECCIÓN DE NIVEL");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op3Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op3Objects1[i].setString(">> 3 · TUTORIAL <<");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op4Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op4Objects1[i].setString("4 · SALAS DE PRUEBA");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 4);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Menu_Op1"), gdjs.TituloCode.GDMenu_9595Op1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op2"), gdjs.TituloCode.GDMenu_9595Op2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op3"), gdjs.TituloCode.GDMenu_9595Op3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Menu_Op4"), gdjs.TituloCode.GDMenu_9595Op4Objects1);
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op1Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op1Objects1[i].setString("1 · JUGAR");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op2Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op2Objects1[i].setString("2 · SELECCIÓN DE NIVEL");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op3Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op3Objects1[i].setString("3 · TUTORIAL");
}
}
{for(var i = 0, len = gdjs.TituloCode.GDMenu_9595Op4Objects1.length ;i < len;++i) {
    gdjs.TituloCode.GDMenu_9595Op4Objects1[i].setString(">> 4 · SALAS DE PRUEBA <<");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "W");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(4);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "W");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "s");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "S");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "s");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "S");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() < 4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu_Op1"), gdjs.TituloCode.GDMenu_9595Op1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op1Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "");
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu_Op2"), gdjs.TituloCode.GDMenu_9595Op2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "");
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu_Op3"), gdjs.TituloCode.GDMenu_9595Op3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op3Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "");
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu_Op4"), gdjs.TituloCode.GDMenu_9595Op4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TituloCode.mapOfGDgdjs_9546TituloCode_9546GDMenu_95959595Op4Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "");
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "u");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "U");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "t");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "T");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Salas", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Num1");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "1");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Nivel 1", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Num2");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "2");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Nivel 2", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Num3");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "3");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SFX_UI", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Nivel 3", false);
}
}

}


};

gdjs.TituloCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TituloCode.GDFondoTituloObjects1.length = 0;
gdjs.TituloCode.GDFondoTituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoTituloObjects1.length = 0;
gdjs.TituloCode.GDFondoTituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoPausaObjects1.length = 0;
gdjs.TituloCode.GDFondoPausaObjects2.length = 0;
gdjs.TituloCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDPausa_9595SubObjects1.length = 0;
gdjs.TituloCode.GDPausa_9595SubObjects2.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.TituloCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoDerrotaObjects1.length = 0;
gdjs.TituloCode.GDFondoDerrotaObjects2.length = 0;
gdjs.TituloCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.TituloCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.TituloCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.TituloCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.TituloCode.GDFondoVictoriaObjects1.length = 0;
gdjs.TituloCode.GDFondoVictoriaObjects2.length = 0;
gdjs.TituloCode.GDVictoria_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDVictoria_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDVictoria_9595StatsObjects1.length = 0;
gdjs.TituloCode.GDVictoria_9595StatsObjects2.length = 0;
gdjs.TituloCode.GDVictoria_9595PromptObjects1.length = 0;
gdjs.TituloCode.GDVictoria_9595PromptObjects2.length = 0;
gdjs.TituloCode.GDFondoSalasObjects1.length = 0;
gdjs.TituloCode.GDFondoSalasObjects2.length = 0;
gdjs.TituloCode.GDSalas_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDSalas_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDSalas_9595SubObjects1.length = 0;
gdjs.TituloCode.GDSalas_9595SubObjects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Desc1Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Desc1Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Desc2Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Desc2Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDSalas_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoObjects1.length = 0;
gdjs.TituloCode.GDFondoObjects2.length = 0;
gdjs.TituloCode.GDSolidoObjects1.length = 0;
gdjs.TituloCode.GDSolidoObjects2.length = 0;
gdjs.TituloCode.GDJugadorObjects1.length = 0;
gdjs.TituloCode.GDJugadorObjects2.length = 0;
gdjs.TituloCode.GDPuertaObjects1.length = 0;
gdjs.TituloCode.GDPuertaObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595BarraObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595BarraObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595NivelObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595NivelObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595AlmasObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595AlmasObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595VidasObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595VidasObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595AvisoObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595AvisoObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595DashObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595DashObjects2.length = 0;
gdjs.TituloCode.GDJefeObjects1.length = 0;
gdjs.TituloCode.GDJefeObjects2.length = 0;
gdjs.TituloCode.GDOndaIzqObjects1.length = 0;
gdjs.TituloCode.GDOndaIzqObjects2.length = 0;
gdjs.TituloCode.GDOndaDerObjects1.length = 0;
gdjs.TituloCode.GDOndaDerObjects2.length = 0;
gdjs.TituloCode.GDGolpePalaObjects1.length = 0;
gdjs.TituloCode.GDGolpePalaObjects2.length = 0;
gdjs.TituloCode.GDAlmaObjects1.length = 0;
gdjs.TituloCode.GDAlmaObjects2.length = 0;
gdjs.TituloCode.GDFarolCheckpointObjects1.length = 0;
gdjs.TituloCode.GDFarolCheckpointObjects2.length = 0;
gdjs.TituloCode.GDPalaRecogibleObjects1.length = 0;
gdjs.TituloCode.GDPalaRecogibleObjects2.length = 0;
gdjs.TituloCode.GDEnemyObjects1.length = 0;
gdjs.TituloCode.GDEnemyObjects2.length = 0;
gdjs.TituloCode.GDPowerUpDashObjects1.length = 0;
gdjs.TituloCode.GDPowerUpDashObjects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.TituloCode.GDEnemyMeleeObjects1.length = 0;
gdjs.TituloCode.GDEnemyMeleeObjects2.length = 0;
gdjs.TituloCode.GDPinchosObjects1.length = 0;
gdjs.TituloCode.GDPinchosObjects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.TituloCode.GDMiniJefeObjects1.length = 0;
gdjs.TituloCode.GDMiniJefeObjects2.length = 0;
gdjs.TituloCode.GDPowerUpRangoObjects1.length = 0;
gdjs.TituloCode.GDPowerUpRangoObjects2.length = 0;

gdjs.TituloCode.eventsList0(runtimeScene);
gdjs.TituloCode.GDFondoTituloObjects1.length = 0;
gdjs.TituloCode.GDFondoTituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoTituloObjects1.length = 0;
gdjs.TituloCode.GDFondoTituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op1_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op2_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op3_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4Objects2.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595Op4_9595SubObjects2.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDMenu_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoPausaObjects1.length = 0;
gdjs.TituloCode.GDFondoPausaObjects2.length = 0;
gdjs.TituloCode.GDPausa_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDPausa_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDPausa_9595SubObjects1.length = 0;
gdjs.TituloCode.GDPausa_9595SubObjects2.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion1Objects1.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion1Objects2.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion2Objects1.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion2Objects2.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion3Objects1.length = 0;
gdjs.TituloCode.GDPausa_9595Opcion3Objects2.length = 0;
gdjs.TituloCode.GDPausa_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDPausa_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoDerrotaObjects1.length = 0;
gdjs.TituloCode.GDFondoDerrotaObjects2.length = 0;
gdjs.TituloCode.GDDerrota_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDDerrota_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDDerrota_9595CausaObjects1.length = 0;
gdjs.TituloCode.GDDerrota_9595CausaObjects2.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat1Objects1.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat1Objects2.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat2Objects1.length = 0;
gdjs.TituloCode.GDDerrota_9595Stat2Objects2.length = 0;
gdjs.TituloCode.GDDerrota_9595PromptObjects1.length = 0;
gdjs.TituloCode.GDDerrota_9595PromptObjects2.length = 0;
gdjs.TituloCode.GDFondoVictoriaObjects1.length = 0;
gdjs.TituloCode.GDFondoVictoriaObjects2.length = 0;
gdjs.TituloCode.GDVictoria_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDVictoria_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDVictoria_9595StatsObjects1.length = 0;
gdjs.TituloCode.GDVictoria_9595StatsObjects2.length = 0;
gdjs.TituloCode.GDVictoria_9595PromptObjects1.length = 0;
gdjs.TituloCode.GDVictoria_9595PromptObjects2.length = 0;
gdjs.TituloCode.GDFondoSalasObjects1.length = 0;
gdjs.TituloCode.GDFondoSalasObjects2.length = 0;
gdjs.TituloCode.GDSalas_9595TituloObjects1.length = 0;
gdjs.TituloCode.GDSalas_9595TituloObjects2.length = 0;
gdjs.TituloCode.GDSalas_9595SubObjects1.length = 0;
gdjs.TituloCode.GDSalas_9595SubObjects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion1Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion1Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion2Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion2Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion3Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion3Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion4Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion4Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion5Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion5Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion6Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Opcion6Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Desc1Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Desc1Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595Desc2Objects1.length = 0;
gdjs.TituloCode.GDSalas_9595Desc2Objects2.length = 0;
gdjs.TituloCode.GDSalas_9595AyudaObjects1.length = 0;
gdjs.TituloCode.GDSalas_9595AyudaObjects2.length = 0;
gdjs.TituloCode.GDFondoObjects1.length = 0;
gdjs.TituloCode.GDFondoObjects2.length = 0;
gdjs.TituloCode.GDSolidoObjects1.length = 0;
gdjs.TituloCode.GDSolidoObjects2.length = 0;
gdjs.TituloCode.GDJugadorObjects1.length = 0;
gdjs.TituloCode.GDJugadorObjects2.length = 0;
gdjs.TituloCode.GDPuertaObjects1.length = 0;
gdjs.TituloCode.GDPuertaObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595BarraObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595BarraObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595NivelObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595NivelObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595AlmasObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595AlmasObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595VidasObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595VidasObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595AvisoObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595AvisoObjects2.length = 0;
gdjs.TituloCode.GDHUD_9595DashObjects1.length = 0;
gdjs.TituloCode.GDHUD_9595DashObjects2.length = 0;
gdjs.TituloCode.GDJefeObjects1.length = 0;
gdjs.TituloCode.GDJefeObjects2.length = 0;
gdjs.TituloCode.GDOndaIzqObjects1.length = 0;
gdjs.TituloCode.GDOndaIzqObjects2.length = 0;
gdjs.TituloCode.GDOndaDerObjects1.length = 0;
gdjs.TituloCode.GDOndaDerObjects2.length = 0;
gdjs.TituloCode.GDGolpePalaObjects1.length = 0;
gdjs.TituloCode.GDGolpePalaObjects2.length = 0;
gdjs.TituloCode.GDAlmaObjects1.length = 0;
gdjs.TituloCode.GDAlmaObjects2.length = 0;
gdjs.TituloCode.GDFarolCheckpointObjects1.length = 0;
gdjs.TituloCode.GDFarolCheckpointObjects2.length = 0;
gdjs.TituloCode.GDPalaRecogibleObjects1.length = 0;
gdjs.TituloCode.GDPalaRecogibleObjects2.length = 0;
gdjs.TituloCode.GDEnemyObjects1.length = 0;
gdjs.TituloCode.GDEnemyObjects2.length = 0;
gdjs.TituloCode.GDPowerUpDashObjects1.length = 0;
gdjs.TituloCode.GDPowerUpDashObjects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95951Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95951Objects2.length = 0;
gdjs.TituloCode.GDEnemyMeleeObjects1.length = 0;
gdjs.TituloCode.GDEnemyMeleeObjects2.length = 0;
gdjs.TituloCode.GDPinchosObjects1.length = 0;
gdjs.TituloCode.GDPinchosObjects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95952Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95952Objects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95953Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95953Objects2.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95954Objects1.length = 0;
gdjs.TituloCode.GDPlataformaMovil_95954Objects2.length = 0;
gdjs.TituloCode.GDMiniJefeObjects1.length = 0;
gdjs.TituloCode.GDMiniJefeObjects2.length = 0;
gdjs.TituloCode.GDPowerUpRangoObjects1.length = 0;
gdjs.TituloCode.GDPowerUpRangoObjects2.length = 0;


return;

}

gdjs['TituloCode'] = gdjs.TituloCode;
