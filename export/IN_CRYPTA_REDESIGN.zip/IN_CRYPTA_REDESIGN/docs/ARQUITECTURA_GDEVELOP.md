# Arquitectura GDevelop (estado verificado en el JSON)

## Escenas (15)

| Escena | Instancias | Eventos de nivel superior | Objetos |
|---|---|---|---|
| Titulo | 12 | 23 | 12 |
| Pausa | 7 | 12 | 7 |
| Derrota | 6 | 3 | 6 |
| Victoria | 4 | 2 | 4 |
| Salas | 12 | 25 | 12 |
| Tutorial | 62 | 39 | 20 |
| Nivel 1 | 146 | 49 | 23 |
| Nivel 2 | 127 | 33 | 27 |
| Nivel 3 | 125 | 76 | 29 |
| Sala 1 | 146 | 49 | 23 |
| Sala 2 | 37 | 72 | 23 |
| Sala 3 | 37 | 72 | 23 |
| Sala 4 | 42 | 40 | 21 |
| Sala 5 | 44 | 47 | 21 |
| Sala 6 | 51 | 83 | 23 |

Las escenas Nivel 1 y Sala 1 tienen las mismas cifras de instancias y eventos, pero comparadas elemento por elemento son distintas. No son copias.

## Hojas de eventos externas (7)

- **IN_CRYPTA_CONTROLES** (asociada a Tutorial, 17 eventos): movimiento, salto, coyote, buffer y dash. Es la hoja de entrada principal.
- **IN_CRYPTA_HUD** (asociada a Tutorial, 15 eventos): vidas, almas, aviso, controles contextuales.
- **IN_CRYPTA_COMUN_01** a **05**: creadas por el refactor. Contienen tramos de eventos idénticos que estaban copiados en varias escenas.
  - COMUN_01 (28 eventos, Nivel 2 y 3): usa Enemy, EnemyMelee, GolpePala y Jugador.
  - COMUN_02 (4 eventos, Nivel 3 y Salas 2, 3, 6): incluye el toggle de F1 (`reducir_movimiento`).
  - COMUN_03 (3 eventos, varias escenas): incluye el toggle de F1 y otro bloque de Jugador.
  - COMUN_04 (1 evento, Pausa y Salas) y COMUN_05 (1 evento, 10 escenas de juego).

Verificación del refactor: si se reemplaza cada evento Link por el contenido de su hoja, las 15 escenas quedan idénticas al original (archivo previo al refactor). Esto verifica la equivalencia estructural, no el comportamiento en GDevelop.

Duplicación que queda: el ataque (J y clic izquierdo) está repetido en 10 escenas con pequeñas variaciones, y el pausa (Escape) está una vez por escena. Unificarlos requiere revisar cada escena en el editor.

## Comportamientos y objetos
- **Jugador**: PlatformerObject, con controles por defecto desactivados.
- **Enemy, EnemyMelee, MiniJefe**: PlatformerObject.
- **Solido** (TiledSprite): comportamiento Platform. Se oculta con Hide al empezar cada escena de juego (verificado en Tutorial, Nivel 1, 2, 3 y Salas). La colisión sigue activa porque el arte del fondo ya dibuja las plataformas; esto debe confirmarse en el juego.
- **PlataformaMovil_1 a _4**: comportamiento Platform. Se mueven con eventos (en Nivel 3, PlataformaMovil_1 oscila en X con `sin(TimeFromStart())`).
- **Jefe**: sin comportamiento. Su movimiento depende de eventos.
- **Pinchos, Puerta, Alma, FarolCheckpoint, PowerUp, PalaRecogible**: sprites sin comportamiento.

## Capas
Las escenas de juego usan dos capas: la capa base (nombre vacío) y `UI`.

## Variables globales (26)
vidas, almas, almas_totales, almas_para_vida, combo_almas, combo_timer, muertes_totales, reducir_movimiento, nivel_actual, reiniciar, jefe_derrotado, cam_x, cam_y, sacudida_f, sacudida_t, rango_mejorado, checkpoint_x, checkpoint_y, checkpoint_activo, checkpoint_escena, escudo_farol, almas_consagradas, almas_vida_consagradas, minijefe_derrotado, menu_opcion.

Las variables de estado de Jugador (dash_cd, dash_time, buffer_salto, coyote, dashing, dash_aire, tiene_pala, tiene_dash) son variables de objeto.

## Recursos
199 recursos declarados. Todos existen en `assets/`. Sin JavaScript (`JsCode`) en el proyecto.
