# Decisiones y cambios

## Base
Proyecto de partida: `IN_CRYPTA_NATIVO_REFACTOR.json`, que es el archivo más reciente del paquete. Incluye las correcciones de la versión previa (ver abajo) y el refactor de duplicación.

## Cambios aplicados

| # | Cambio | Verificación |
|---|---|---|
| 1 | Farol flotante del Nivel 2 movido de (3910, 450) a (3844, 450), sobre la plataforma. | Verificado en el archivo y con el modelo de alcance. |
| 2 | Título: las teclas 1, 2 y 3 llevan a Tutorial, Nivel 1 y Nivel 2, y la 4 agregada lleva a Salas. Antes llevaban a Nivel 1, 2 y 3, y la 4 no respondía. | Verificado en eventos. |
| 3 | Pie de atajos del título: "1–4 IR DIRECTO". Antes "1–3 IR A NIVELES". | Verificado en el texto. |
| 4 | Descripción del Nivel 2: "salto y dash. La pala se recoge dentro del nivel". Antes decía que la pala estaba disponible. | Verificado en el texto. |
| 5 | Refactor: 5 tramos de eventos idénticos movidos a hojas COMUN_01 a COMUN_05, reemplazados por Link (78 eventos de nivel superior sustituidos). | Verificado por equivalencia estructural. No ejecutado. |

## Cambios no aplicados y por qué

- **Primer hueco del Nivel 2 y Nivel 3.** Requiere dash en el aire o salto mantenido. No se cambió la geometría (dibujada en el fondo) ni la física (afectaría a todos los niveles). Opciones en `DISENO_Y_PROGRESION.md`. Es una decisión de diseño que necesita la prueba en el juego.
- **Duplicación restante del ataque (J y clic) en 10 escenas.** Unificarla requiere revisar cada escena en el editor. Riesgo alto de romper algo sin poder probar.
- **Render (`linear` frente a `nearest`).** Requiere comparar en una captura real. No se puede hacer aquí. Para pixel art, `nearest` suele conservar mejor los píxeles; la decisión debe tomarse mirando el juego.
- **Inconsistencia de T en Título y Salas.** Menor. Se documentó sin cambiar.
- **Valores 295 y 360 escritos en eventos.** Funcionan, pero no están documentados como valores de diseño. Se documentaron en `CONTROLES_Y_FISICAS.md`. Conviene decidir si son intencionales antes de cambiarlos.

## Extensiones de la tienda

No se instaló ninguna extensión. Motivo: una extensión se instala desde el editor, no escribiendo JSON, y no puedo hacerlo aquí. Procedimiento verificado en la documentación oficial:
1. Project Manager → "Create or search for new extensions" (o el botón + de la sección Extensions).
2. Buscar la extensión y abrirla.
3. "Install in project".

Candidata: **Advanced platformer movements** (air jump, wall jump, coyote time, dash horizontal, dash en picada). Su dash horizontal tiene por defecto recarga 0,25 s y desaceleración 3000; la duración no figura en la documentación revisada.

Riesgo de integración: reemplazar el dash y el coyote actuales implica reconfigurar los eventos de IN_CRYPTA_CONTROLES. Hay que probarla en una copia del proyecto y no mezclar las dos implementaciones. El jump buffer no está en la extensión y debe quedarse nativo.

## Discrepancias con el LEEME original
- La ruta de publicación en gd.games del LEEME (File → Export → Web → Publish on gd.games) no coincide con la documentación oficial (Share → gd.games → Publish game).
- "Compilado con 15 escenas y cero diagnósticos": no se pudo reproducir aquí. El número de escenas coincide; los diagnósticos requieren GDevelop.
- "Sin JavaScript", "Solido se oculta al iniciar", "Shift no salta" y "15 escenas": coinciden con el archivo.

## Lo que se pidió y no se entregó
- Carpeta `build/` con HTML5 jugable.
- Capturas de Título, Tutorial, niveles y una Sala.
- Verificación de apertura y compilación en GDevelop.
- Pruebas jugables.
Esto requiere GDevelop Desktop y navegador, que no están disponibles en este entorno.
