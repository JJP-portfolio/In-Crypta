# Controles y físicas

## Controles de juego (verificados en eventos)

| Acción | Tecla | Dónde está el evento |
|---|---|---|
| Mover izquierda / derecha | ← / → (`Left`, `Right`) | Hoja IN_CRYPTA_CONTROLES |
| Saltar | Espacio (`Space`) | Hoja IN_CRYPTA_CONTROLES |
| Dash (si está desbloqueado) | X (`x` y `X`) | Hoja IN_CRYPTA_CONTROLES |
| Atacar (si está la pala) | J (`j` y `J`) o clic izquierdo | Repetido en 10 escenas de juego |
| Pausa | Escape | Una vez por escena de juego |
| Reducir sacudida de cámara | F1 | Alterna `reducir_movimiento`. Está en las hojas IN_CRYPTA_COMUN_02 y IN_CRYPTA_COMUN_03, que las escenas de juego enlazan |

Los controles por defecto de PlatformerObject están desactivados (`ignoreDefaultControls = true`), así que Shift no salta ni activa el dash. Verificado: no aparece `Shift` en ningún evento.

## Menús

| Escena | Teclas |
|---|---|
| Título | ↑ / ↓ navegan. Enter o Espacio confirman. 1, 2, 3, 4 van directo a Tutorial, Nivel 1, Nivel 2 y Salas. U va a Tutorial. T va a Salas. Clic sobre las opciones. |
| Pausa | ↑ / ↓ navegan. Enter confirma. Escape vuelve al juego. |
| Salas | ↑ / ↓ navegan. Enter confirma. 1 a 6 van directo a Sala 1 a Sala 6. Escape o T vuelven al Título. |

Inconsistencia menor: en el Título, T lleva a Salas, y en Salas, T lleva de vuelta al Título. Conviene unificarlo.

## Físicas de Jugador (PlatformerObject, verificado en el JSON)

| Parámetro | Valor |
|---|---|
| Gravedad | 1500 |
| Impulso de salto (jumpSpeed) | 620 |
| Salto mantenido (jumpSustainTime) | 0,12 s |
| Caída máxima | 900 |
| Velocidad máxima | 250 |
| Aceleración / desaceleración | 20000 / 20000 |
| Pendiente máxima | 60° |
| Salto repetido | desactivado |
| Bajar por plataformas de paso | activado |

## Valores de dash, buffer y coyote (eventos, verificado)

| Variable | Valor asignado |
|---|---|
| dash_time (duración del dash) | 0,20 s |
| dash_cd (recarga) | 0,60 s |
| Velocidad durante el dash | 560 (escrita como MaxSpeed) |
| Gravedad durante el dash | 0 |
| buffer_salto (pulsación anticipada) | 0,12 s |
| coyote (tiempo de gracia al caer) | 0,10 s |
| dash_aire (dash en el aire) | se restablece a 1 al tocar el suelo |

## Valores escritos en eventos sin documentar (verificados)
- **MaxSpeed 295**: se escribe al saltar durante el dash. Da más velocidad que la máxima normal (250). No figura en la documentación original.
- **JumpSpeed 360**: se escribe al pisar un enemigo con la pala (rebote). Tampoco figura en la documentación original.

## Estimaciones de alcance (modelo, no medido)
- Altura del salto sin mantener Espacio: unos 128 px.
- Altura manteniendo Espacio: unos 200 px.
- Alcance horizontal a velocidad máxima: unos 200 px.
- Dash: unos 112 px en 0,20 s, frente a 50 px caminando en el mismo tiempo. Es un aumento de unos 62 px.

## Coyote y buffer: implementación
Están implementados con eventos nativos (variables con temporizador) dentro de IN_CRYPTA_CONTROLES. No hay física paralela en JavaScript.

## Extensión opcional
La extensión comunitaria "Advanced platformer movements" trae air jump, wall jump, coyote time y dash horizontal. No trae buffer. No se instaló en este paquete. Ver `DECISIONES_Y_CAMBIOS.md`.
