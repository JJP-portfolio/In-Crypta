# Diseño y progresión

Las escenas y su orden están en el proyecto. Las cifras de alcanzabilidad son **estimaciones de un modelo simplificado** del salto del motor (impulso 620, gravedad 1500, velocidad 250, salto mantenido 0,12 s, dash ≈ +62 px en el aire). El modelo no incluye enemigos, pinchos ni el movimiento de las plataformas móviles. Sirve para encontrar problemas de ritmo, no reemplaza probar en el juego.

## Escenas de campaña

| Escena | Rol | Qué se verificó en el archivo | Estimación del modelo |
|---|---|---|---|
| Tutorial | Primer salto y lectura de almas/farol | 1 farol, 1 puerta, 32 plataformas, 13 almas | La puerta se alcanza con salto corto |
| Nivel 1 (Camposanto) | Salto consolidado, power-up del dash, enemigos | 2 faroles, 1 PowerUpDash, 4 enemigos, 1 plataforma móvil | La puerta y todos los objetos se alcanzan con salto corto |
| Nivel 2 (Cripta) | Pala, pisotón, dash en el aire, pinchos | 2 faroles, pala, 32 pinchos, 4 plataformas móviles | Salto corto no alcanza la puerta; con dash en el aire sí |
| Nivel 3 (Osario) | Combinación, MiniJefe y Jefe | 3 faroles, PowerUpRango, MiniJefe, Jefe | Salto corto no alcanza la puerta; con dash en el aire sí |

Salas 1 a 6: práctica aislada. Cada una tiene su propio conjunto de eventos. No se evaluaron por alcanzabilidad en este paquete.

## Hallazgo principal: el primer hueco del Nivel 2

El primer hueco del Nivel 2 mide unos 224 px, y la plataforma de llegada está 32 px más arriba. Con salto corto el alcance estimado es de unos 193 px, así que no se cruza. Hay dos formas de cruzarlo, ambas verificadas en el modelo:
- **Dash en el aire** (X con el salto en curso). El Nivel 2 empieza con el dash habilitado (`tiene_dash = 1`).
- **Mantener Espacio** durante el salto.

El riesgo es de enseñanza: un jugador que solo toca Espacio cae siempre en ese punto y puede interpretarlo como un salto roto. No se verificó qué texto de ayuda muestra el HUD en ese momento. Hay que comprobarlo en el juego.

Opciones para decidir (ninguna aplicada en este paquete):
1. Enseñar el dash en el aire en el Nivel 1 o en la Sala 4 antes de llegar al Nivel 2.
2. Agregar un aviso visible antes del hueco del Nivel 2 (texto en el HUD o en la escena).
3. Ajustar la física. Afecta a todos los niveles a la vez, así que debe decidirse con las pruebas en mano.

No conviene acortar el hueco moviendo las plataformas: están dibujadas en el fondo, y moverlas sin redibujar el arte desalinearía las colisiones.

## Checkpoints

- El farol flotante del Nivel 2 se movió a (3844, 450), sobre la plataforma. Verificado en el archivo.
- En el modelo, todos los faroles de los cuatro niveles principales quedan alcanzables. En el Nivel 3, los 3 faroles requieren dash en el aire o salto mantenido; con salto corto no se alcanzan.
- Los faroles del Nivel 1 también son alcanzables con salto corto.

## Pendiente de decisión
- Confirmar con el jugador qué checkpoint del Nivel 1 se ve mal (no se encontró error objetivo en su posición).
- Decidir la política de render (ver `DECISIONES_Y_CAMBIOS.md`).
