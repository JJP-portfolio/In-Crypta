# IN CRYPTA — proyecto GDevelop refactorizado

**Estado: no verificado en GDevelop.** Este paquete se armó sin GDevelop ni navegador disponibles. Todo lo que figura como verificado fue comprobado sobre el archivo JSON, no al ejecutarlo. Antes de dar el proyecto por bueno hay que abrirlo, compilarlo, previsualizarlo y exportarlo (ver `QA_Y_PRUEBAS.md`).

## Qué contiene
- `IN_CRYPTA_REDESIGN.json`: proyecto GDevelop 5.6 (gdVersion 5.6.285). 15 escenas y 7 hojas de eventos externas.
- `assets/`: 216 archivos (PNG, WAV y una fuente TTF) que el proyecto referencia. Tienen que quedar en la misma carpeta que el JSON.
- `docs/`: documentación del proyecto.

## Cómo abrirlo
1. Descomprimí la carpeta `IN_CRYPTA_REDESIGN` completa.
2. En GDevelop: Open a project → elegí `IN_CRYPTA_REDESIGN.json`. No lo muevas sin `assets/`.
3. Compilá las escenas y revisá la lista de diagnósticos. Si aparece alguno, anotalo en `QA_Y_PRUEBAS.md`.
4. Preview (▶) desde la escena Título.

## Cómo exportar y publicar
- **gd.games:** desde el editor, Share → gd.games → Publish game (según la documentación oficial de GDevelop, https://wiki.gdevelop.io/gdevelop5/publishing/web/). El LEEME del proyecto original indica otra ruta (File → Export → Web); esa instrucción no coincide con la documentación oficial y debería corregirse.
- **HTML5 local:** la exportación manual está documentada en https://wiki.gdevelop.io/gdevelop5/publishing/html5_game_in_a_local_folder/. No se generó carpeta `build/` en este paquete.

## Qué no es
No es un rediseño completo con nueva geometría ni arte nuevo. Es el proyecto existente con:
- correcciones verificables (farol flotante, atajos del título),
- un refactor de duplicación verificado por equivalencia (5 hojas compartidas),
- documentación que describe lo que hay realmente en el archivo.

Las decisiones de diseño pendientes están en `DECISIONES_Y_CAMBIOS.md`.
