# Fuentes y licencias de assets

## Inventario
- 216 archivos en `assets/`:
  - PNG: sprites, fondos, HUD, íconos, partículas y las variantes `*_legible.png` de los fondos.
  - WAV: 19 efectos de sonido (sfx_*).
  - TTF: `NotoSerifDisplay-Bold.ttf` (fuente de título y menús).

## Origen y licencia

**No se agregaron assets externos en este paquete.** Todos los archivos vienen del proyecto original.

- **Sprites, fondos, HUD y sonidos:** el LEEME del proyecto original los describe como producidos para el juego (estética gótica de pixel art con paleta definida). No cita ninguna fuente externa ni licencia. Si alguno proviene de un tercero, el equipo debe documentar la fuente exacta, la licencia y la atribución requerida.
- **Variantes `*_legible.png` de los fondos:** el LEEME indica que son versiones procesadas de los fondos originales, con una curva de brillo moderada. Son transformaciones de arte del equipo.
- **NotoSerifDisplay-Bold.ttf:** la familia Noto suele distribuirse bajo SIL Open Font License. Esto no está verificado en el paquete. Antes de publicar, confirmar la licencia en la fuente oficial y conservar el archivo de licencia junto con la fuente.

## Pendiente
- Confirmar con el equipo el origen de cada sprite y de cada efecto de sonido.
- Confirmar la licencia de la fuente.
- Si se agregan assets externos en el futuro, registrar aquí la URL exacta, la licencia, el autor y la atribución.
