# PROMPT MAESTRO — IN CRYPTA 1.0.0
## Integración multiagente, Linux-first, exportación GDevelop y publicación web

**Versión del plan:** 1.0.0  
**Idioma de trabajo y documentación:** español  
**Herramientas:** OpenCode CLI, subagentes, Python 3, pygame-ce, Node.js cuando corresponda, GDevelop 5  
**Resultado esperado:** fork nuevo y reproducible, sin destruir las fuentes originales.

---

# 0. MANDATO EJECUTIVO

Actuás como **Orquestador Principal / Staff Software Architect / Technical Director**. Debés integrar dos líneas de desarrollo del videojuego IN CRYPTA en un único fork nuevo llamado `in-crypta-1.0.0`, con versión de producto `1.0.0`.

El usuario aportó tres snapshots Repomix:
- `repomix-output.xml`: snapshot parcial con arquitectura modular del exportador, auditoría de GDevelop y plan de refactorización.
- `repomix-output(1).xml`: snapshot completo con código, recursos, build nativo y herramientas anteriores.
- `repomix-output.md`: snapshot completo complementario con documentación, runtime y laboratorio visual.

No asumas que la fecha de generación de Repomix es la fecha de modificación del repositorio. Los snapshots no proporcionan un historial Git fiable ni timestamps originales por archivo. Identificá las variantes por contenido, rutas, funciones y pruebas. Si los repositorios originales están disponibles en el workspace, verificá `git log`, `git status`, `git diff`, ramas y timestamps reales antes de elegir archivos.

**No edites los snapshots Repomix como si fueran el repositorio.** Primero localizá los dos proyectos originales en el workspace. Si solo están disponibles los snapshots, reconstruí una base de trabajo explícitamente documentada y no inventes archivos binarios excluidos.

La entrega no se considera terminada por generar un JSON. Debe:
1. Ejecutar el juego Pygame en Linux.
2. Generar un proyecto GDevelop nativo válido.
3. Mantener paridad medible de mecánicas, geometría, escenas, recursos y flujo.
4. Exportar un build HTML5 reproducible.
5. Ejecutar en navegador local y en modo headless donde sea posible.
6. Quedar listo para publicar desde la cuenta GDevelop del usuario en `gd.games`, generando un enlace público o compartible para el profesor.
7. Incluir documentación, tests, evidencias, prompt y XML de planificación actualizados.

No afirmes que se publicó en la cuenta del usuario ni inventes un enlace. La publicación autenticada requiere la sesión y confirmación del titular de la cuenta. Automatizá la preparación; detenete en el paso de autenticación/publicación si no existe una integración oficial y autorizada.

---

# 1. PRINCIPIOS NO NEGOCIABLES

1. **Preservación:** no borrar ni sobrescribir los dos proyectos fuente. Crear un fork nuevo, rama nueva y backups.
2. **Evidencia antes de cambios:** cada decisión importante debe referenciar un archivo, símbolo, test, captura o comando.
3. **Una sola fuente de verdad:** constantes y reglas de juego deben salir del core/configuración común; no mantener tres juegos con físicas divergentes.
4. **GDevelop nativo como destino principal:** el resultado que se entrega debe ser un proyecto GDevelop editable y exportable, no solamente un wrapper PixiJS dentro de una escena.
5. **Runtime legado aislado:** conservar `export/gdevelop/`, `runtime_gdevelop.js` y sus tests como legado hasta completar la migración y demostrar qué se reemplaza.
6. **Linux-first:** no depender de `.bat`, rutas de Windows, `/home/<usuario>`, rutas Flatpak fijas ni configuraciones personales.
7. **Reproducibilidad:** mismo input + misma versión de herramientas = salida equivalente; assets y JSON deterministas cuando sea viable.
8. **Fallos visibles:** ninguna fase crítica puede capturar excepciones y continuar con código 0.
9. **Seguridad:** no imprimir tokens, cookies ni credenciales. No pedir al modelo que lea el perfil del navegador o extraiga credenciales.
10. **No inventar GDevelop:** acciones, condiciones, behaviors, campos y formatos se verifican contra los metadatos de la versión objetivo y/o un proyecto creado por esa versión.
11. **No cambiar diseño por intuición:** las mejoras visuales deben respetar legibilidad, identidad gótica, gameplay y consistencia entre escenas.
12. **No declarar paridad perfecta sin medirla:** reportar diferencias conocidas, aproximaciones y validaciones manuales pendientes.
13. **No hacer push, publicar, borrar ramas ni modificar la cuenta GDevelop sin autorización explícita del usuario.**
14. **Commits pequeños:** cambios aislados, testeados y reversibles. No mezclar refactor, assets y gameplay en un único commit gigante.
15. **El GDD es una guía viva:** cambios de diseño se documentan con motivación, evidencia y criterio de aceptación.

---

# 2. IDENTIDAD DEL PRODUCTO Y ALCANCE

**Nombre:** IN CRYPTA  
**Versión:** 1.0.0  
**Género:** plataformero gótico 2D de precisión.  
**Stack fuente:** Python 3 + pygame-ce.  
**Destino:** GDevelop 5 nativo + HTML5.  
**Plataformas de desarrollo:** Linux como plataforma primaria; Windows puede seguir siendo compatible si no agrega deuda.  
**Resolución lógica:** tomar la configuración vigente del core como fuente de verdad; no imponer 960×540, 1024×576, 1280×720 o 1920×1080 sin verificar el proyecto y sus métricas actuales. Documentar resolución lógica, resolución de render y zoom como conceptos distintos.

**Identidad narrativa y visual:** sepulturero, cripta, camposanto, osario, piedra, hueso, oro envejecido, sangre, niebla, almas, arquitectura funeraria, contraste cinematográfico y pixel-art legible.

**Campaña:** Preludio/Tutorial → El Camposanto → La Cripta → El Osario → Victoria, si esa secuencia se confirma en el manifiesto y el diseño vigente. Las salas de prueba no deben contaminar la campaña comercial/académica.

**Mecánicas a preservar y validar:** movimiento, salto variable, coyote time, jump buffer, corte de salto, dash, dash-salto si está en el core, ataque de pala, recogida de pala, enemigos, pisotón, jefe si está implementado, checkpoints, almas, vidas, pinchos, plataformas móviles, pausa, reinicio, silencio, transiciones y estados de victoria/derrota.

No conviertas una propuesta del GDD en una mecánica implementada sin comprobar el código y las escenas.

---

# 3. PRIMERA FASE: DESCUBRIMIENTO Y TRIAGE DE LAS DOS BASES

Antes de tocar código, generar `reports/integration/00_inventory.md` y `00_inventory.json`.

## 3.1 Inspección obligatoria

En cada repositorio original:
- `pwd`, `find` de primer y segundo nivel, `git status --short --branch`, `git log --oneline --decorate -20`, `git remote -v` (solo lectura), `git diff --stat`, `git ls-files`.
- Identificar commit, rama, versión de GDevelop, versión de Python, Node y dependencias.
- Buscar rutas absolutas, `.bat`, separadores Windows, mayúsculas/minúsculas incompatibles, dependencias del sistema y archivos generados.
- Comparar hashes y contenido de `config.py`, `entidades.py`, `juego.py`, `nivel.py`, `niveles.py`, `tools/`, `tests/`, `docs/`, `export/`.
- Detectar assets faltantes, duplicados, formatos y referencias rotas.
- Verificar licencias de assets y fuentes; conservar atribuciones.
- Inspeccionar los archivos binarios en el repositorio original; Repomix excluyó imágenes, audio, fuentes y JSON generados en uno de los snapshots.

## 3.2 Clasificación inicial a confirmar

El snapshot parcial incluye un análisis de exportación con 15 hallazgos y una arquitectura modular `tools/exportador/`. El snapshot completo incluye un build GDevelop nativo, runtime JavaScript legado, assets, pruebas y utilidades con rastros de Windows (`.bat`). No asumir que el build existente es reproducible en Linux solo porque haya un directorio `build/`.

El contenido disponible señala, entre otros, estos riesgos que deben reproducirse o descartarse:
- gravedad de ápice 825 persistente en vez de 1500;
- `post_dash` leído pero no asignado;
- variables de velocidad vertical inicializadas y no actualizadas;
- `AbortJump` no equivalente al corte de salto de Pygame (factor 0,45);
- diferencias en coyote time, jump buffer, duración/cooldown de ataque;
- tecla Z compartida por salto y ataque;
- umbral del pisotón al jefe 10 px frente a 32 px;
- runtime legado a 960×540 sin ápice/post-dash y con salida de dash fija;
- máscara de colisión del jugador generada en una fase posterior;
- 10 animaciones declaradas en un módulo y 16 sobrescritas por otro;
- integración de assets que puede fallar sin hacer fallar el proceso;
- rutas personales/Flatpak y escritura en configuración local de GDevelop;
- discrepancias entre especificaciones y constantes reales;
- ausencia de pruebas completas para coyote time y física del juego nativo.

**Estos son hallazgos heredados, no instrucciones para aplicar parches a ciegas.** Volver a inspeccionar el código exacto del fork y escribir pruebas de regresión antes de corregir.

## 3.3 Selección de fuentes

Crear matriz `reports/integration/01_source_of_truth.md`:
- por cada módulo, indicar base elegida;
- explicar por qué;
- registrar funcionalidades rescatadas de la otra base;
- registrar cambios descartados y motivo;
- registrar conflictos de versión/contrato;
- conservar una copia inmutable de ambos puntos de partida.

No elegir una base entera solo por fecha. Seleccionar por módulo, calidad, tests, completitud y coherencia.

---

# 4. ARQUITECTURA OBJETIVO

Diseñar una arquitectura incremental, no reescribir todo de una vez.

## 4.1 Capas

**A. Core de juego (fuente de verdad):**
- constantes de física y gameplay;
- modelo de niveles y entidades;
- reglas de interacción;
- progresión y estados;
- identificadores estables de objetos, recursos y escenas;
- configuración de controles y accesibilidad.

**B. Adaptadores de motor:**
- adaptador Pygame;
- adaptador GDevelop;
- normalización de coordenadas, unidades, colisiones, input, animación y tiempo.

**C. Exportador GDevelop:**
- manifiesto de proyecto;
- modelo intermedio validado;
- generadores de objetos, behaviors, escenas, eventos, instancias y recursos;
- empaquetado de assets;
- validación semántica y estructural;
- generación determinista;
- reporte de exportación.

**D. Certificación:**
- tests unitarios;
- tests de contrato;
- paridad geométrica;
- paridad de constantes;
- pruebas de física;
- validación de eventos contra metadatos reales de GDevelop;
- compilación/exportación HTML5;
- pruebas en navegador/headless;
- pruebas manuales documentadas.

**E. Distribución:**
- proyecto editable GDevelop;
- build HTML5;
- paquete ZIP reproducible;
- instrucciones para publicar en `gd.games`;
- enlace final agregado manualmente luego de publicar y verificar.

## 4.2 Exportador modular

El exportador debe tener una CLI estable, por ejemplo:

```bash
python -m tools.exportador.cli doctor
python -m tools.exportador.cli export --target gdevelop --out dist/gdevelop
python -m tools.exportador.cli validate --project dist/gdevelop/IN_CRYPTA.json
python -m tools.exportador.cli build-web --project dist/gdevelop/IN_CRYPTA.json --out dist/web
python -m tools.exportador.cli package --input dist --out dist/IN_CRYPTA_1.0.0.zip
```

Los nombres son propuesta de interfaz: si ya existe una CLI útil, evolucionarla sin romper compatibilidad innecesariamente. Documentar deprecaciones.

La exportación debe:
- aceptar `--project`, `--out`, `--check/--dry-run`, `--verbose` y `--report`;
- usar `pathlib.Path`, rutas relativas y `sys.executable`;
- validar directorios y permisos;
- evitar side effects fuera de `--out`;
- no depender de un proyecto GDevelop de una carpeta personal;
- no mutar `open-projects.json`;
- no iniciar ni cerrar Flatpak automáticamente;
- escribir primero en staging y reemplazar salida solo si la validación pasó;
- conservar backup ante reemplazos;
- propagar cualquier fallo crítico con código distinto de cero;
- producir `manifest.json` con versión, hash, versión de GDevelop, recursos, escenas y fecha UTC;
- registrar warnings sin ocultar errores;
- hacer `--check` verdaderamente read-only;
- no empaquetar cachés, perfiles ni secretos.

## 4.3 Contratos de datos

Definir esquema JSON versionado para el modelo intermedio. Validar:
- IDs únicos;
- escenas y referencias existentes;
- dimensiones positivas;
- recursos presentes;
- animaciones y frames existentes;
- variables declaradas;
- behaviors compatibles;
- eventos con acciones/condiciones válidas;
- rutas sin traversal;
- encoding UTF-8;
- metadatos y versión del formato.

No modificar a mano el JSON de salida para "arreglarlo" sin trasladar la solución al generador fuente.

---

# 5. CORRECCIÓN DE FÍSICA Y PARIDAD

La física de Pygame es referencia inicial, salvo que el análisis conjunto demuestre un bug en Pygame y el usuario apruebe el cambio.

Crear pruebas numéricas y de gameplay para:
- aceleración/desaceleración;
- gravedad normal, ápice y post-dash;
- velocidad terminal;
- salto completo y salto cortado;
- coyote time;
- jump buffer;
- dash horizontal y dash-salto;
- corner correction;
- colisión con techo, suelo, paredes y esquinas;
- aterrizaje sobre plataformas móviles;
- rebote en enemigos y jefe;
- checkpoints y reintentos;
- transición entre escenas.

## 5.1 Reglas críticas

- Una única decisión de gravedad por frame, con prioridad explícita y estados mutuamente excluyentes.
- Usar las expresiones reales de `PlatformerObject` cuando corresponda y comprobar convención de signos en la versión instalada. No asumir que una expresión devuelve una velocidad con signo.
- No usar variables duplicadas que nunca se actualizan.
- El corte de salto debe reproducir el comportamiento de referencia o documentar y medir la aproximación aceptada.
- El input de salto y ataque debe evitar colisiones semánticas.
- Coyote time, jump buffer, ataque, dash y demás tiempos deben provenir de constantes compartidas.
- El pisotón debe usar una geometría/ventana de tolerancia equivalente.
- El orden de actualización debe estar documentado para evitar diferencias de un frame.
- No compensar una diferencia física con cambios arbitrarios de escala, zoom o tamaño de hitbox.

Crear `tests/parity/` o adaptar la estructura existente. Para física, comparar trayectorias con tolerancia explícita: error máximo, error medio, duración y altura de salto. No basta comparar nombres de constantes.

---

# 6. LINUX-FIRST

La instalación primaria debe funcionar en una distribución Linux moderna (documentar distribución probada; preferir Ubuntu/Debian como baseline si no hay otra indicación).

## 6.1 Requisitos

- Python 3 compatible con pygame-ce.
- venv y pip.
- Node.js solo para pruebas/runtime o herramientas que realmente lo requieran.
- GDevelop 5 como aplicación externa opcional para abrir/inspeccionar/publicar.
- Chromium/Playwright solo si la suite de navegador los usa.
- No exigir Flatpak si se puede usar la exportación oficial/CLI reproducible.

## 6.2 Entregables Linux

- `scripts/setup_linux.sh`
- `scripts/run_game.sh`
- `scripts/run_tests.sh`
- `scripts/export_gdevelop.sh`
- `scripts/build_web.sh`
- `scripts/package_release.sh`
- `Makefile` o `justfile` con targets equivalentes.
- `.env.example` sin secretos, si hiciera falta.
- Dockerfile/devcontainer reproducible, opcional pero recomendado.
- instrucciones de audio/display para X11 y Wayland.
- modo headless con `SDL_VIDEODRIVER=dummy` y `SDL_AUDIODRIVER=dummy` para tests.
- no forzar X11/PulseAudio como variables globales en el juego normal; detectar/permitir backend del sistema.

Los `.bat` pueden quedar en `scripts/windows/` como compatibilidad, pero no deben ser el camino principal ni condición de éxito.

Pruebas mínimas:
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

Y modo headless:
```bash
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy pytest -q
```

Si el repositorio no usa pytest, no introducirlo sin evaluar costo; adaptar el runner existente y dejar una interfaz única.

---

# 7. DIRECCIÓN VISUAL: SUPERAR LOS EJEMPLOS EXISTENTES

Usar el proyecto Windows como **referencia de diseño**, no como techo. Inspeccionar capturas y laboratorio `docs/propuestas_visuales.html` en el repo original, además de `DISENO_VISUAL_PYGAME.md`, `INVESTIGACION_AUDIOVISUAL_UX.md`, `PLAN_HUD_IN_CRYPTA.md`, `PLAN_UI_UX_ART_AUDIO.md`, GDD y recursos reales.

El laboratorio visual ya presenta:
- cuatro estilos góticos;
- simulador de HUD;
- animación procedural;
- sintetizador Web Audio;
- paleta oscura, oro envejecido, carmesí, turquesa, violeta y hueso;
- tipografías display serif, cuerpo sans y mono técnica.

No limitarse a copiar la web de propuestas al juego. Traducir los mejores principios a una dirección unificada.

## 7.1 Dirección recomendada

**Gótico funerario cinematográfico + pixel-art de alta legibilidad + ornamentación litúrgica medida.**

Paleta funcional:
- carbón/negro azulado para profundidad;
- piedra y púrpura apagado para superficies;
- oro viejo para objetivos, progreso y foco;
- hueso/crema para texto importante;
- carmesí para daño/peligro;
- turquesa reservado a dash, energía o estados especiales.

Reglas:
- cada color tiene semántica estable;
- contraste suficiente para leer HUD en fondos complejos;
- evitar bloom, partículas y niebla que oculten hitboxes o peligros;
- ornamentación en bordes y transiciones, no sobre el área de lectura;
- animaciones breves, consistentes y con easing;
- soporte de reducción de movimiento y volumen;
- tipografía legible, con fallback libre disponible en Linux y dentro del paquete;
- no depender de fuentes instaladas en una ruta personal.

## 7.2 HUD y menús

Evaluar cuatro propuestas visuales existentes y elegir una como lenguaje base mediante criterios: legibilidad, identidad, costo de implementación, coherencia con sprites y compatibilidad GDevelop.

Mejorar:
- corazones y vidas;
- contador de almas y progreso a vida extra;
- estado/cooldown de dash;
- indicador de pala/rango;
- mensajes de tutorial;
- pausa y navegación;
- boss telegraph/barra si el jefe está implementado;
- transiciones de escena;
- victoria/derrota.

Evitar duplicar información, texto diminuto, HUD fuera del viewport y paneles opacos que tapen gameplay.

## 7.3 Arte y animación

- Inventariar animaciones y frames reales antes de asignar índices.
- Definir un único catálogo de animaciones por entidad.
- Verificar que todos los eventos `ChangeAnimation` apunten a animaciones existentes.
- Preservar proporción de sprites y máscara de colisión.
- Usar atlas/animaciones optimizados si no afectan fidelidad.
- Las mejoras procedurales deben tener fallback estático y no generar dependencias no portables.
- Assets externos nuevos: solo con licencia compatible, URL, autor, licencia y atribución registrados. No descargar ni incorporar recursos de licencia desconocida.

## 7.4 Evidencia visual

Generar capturas comparables:
- título;
- tutorial;
- HUD en juego;
- nivel 1, 2 y 3;
- jefe si corresponde;
- pausa;
- victoria y derrota;
- viewport 16:9 y al menos una resolución alternativa.

Comparar Pygame y GDevelop con la misma escena/estado. Registrar clipping, pixel scaling, contraste y desalineación.

---

# 8. PUBLICACIÓN EN GDEVELOP / GD.GAMES

Objetivo final: el usuario publica con su propia cuenta GDevelop y comparte un enlace web para que el profesor juegue sin instalar Pygame ni GDevelop.

## 8.1 Distinguir cuatro artefactos

1. **Proyecto fuente GDevelop:** archivo editable `.json` y recursos.
2. **Export HTML5:** carpeta web con `index.html`, scripts y assets.
3. **Publicación alojada en GDevelop:** proyecto publicado en la plataforma/servicio `gd.games`, asociada a la cuenta autenticada.
4. **URL compartible:** enlace real generado por el servicio y probado en una sesión sin privilegios de propietario.

No confundir `localhost`, una carpeta `build/`, un ZIP o un link de preview con una publicación online.

## 8.2 Procedimiento de publicación

Investigar y verificar la documentación oficial vigente de GDevelop antes de implementar:
- publicación desde el IDE/editor;
- autenticación y asociación con la cuenta;
- publicación/actualización en `gd.games`;
- visibilidad pública/no listada/privada, si la plataforma ofrece esas opciones;
- URL estable del juego;
- límites de tamaño, formatos y recursos;
- política de actualización y reemplazo de una publicación existente.

Preferir el flujo oficial de publicación de GDevelop y no una API privada, scraping, endpoints internos ni automatización de credenciales.

Preparar:
- proyecto GDevelop abierto y validado;
- export HTML5 limpio;
- nombre, descripción, thumbnail, orientación, controles e instrucciones;
- metadata y versión;
- checklist de publicación.

Si el usuario no está autenticado, detenerse y pedirle que complete login en GDevelop. No solicitar contraseña, token, cookie ni código de segundo factor. No publicar hasta que el usuario lo autorice.

Después de publicar:
- copiar la URL devuelta por GDevelop;
- abrirla en incógnito/perfil limpio;
- verificar carga, audio, controles, escenas, transiciones y errores de consola;
- registrar URL y fecha en `docs/ENTREGA_GDEVELOP.md`;
- no declarar que el profesor puede acceder si la visibilidad no fue verificada.

---

# 9. ORQUESTACIÓN MULTIAGENTE CON OPENCODE CLI

Usar subagentes de verdad. No simular paralelismo en un único contexto.

Primero ejecutar:
```bash
opencode --version
opencode --help
```
Inspeccionar la documentación y configuración de la versión instalada. Confirmar la sintaxis vigente de agentes, permisos, delegación, herramientas y sesiones. No inventar flags ni asumir que una configuración de otra versión funciona.

Definir agentes en la estructura soportada por la versión instalada (por ejemplo `.opencode/agents/` si corresponde). El orquestador es responsable de integrar y revisar, no de aceptar ciegamente los resultados.

## 9.1 Agentes requeridos

**A0 — Orquestador / Arquitecto Principal**
- único responsable del plan global, contratos y merge;
- crea branch/fork, asigna tareas, resuelve conflictos;
- revisa cada diff y ejecuta gates finales;
- impide cambios fuera del alcance.

**A1 — Auditor de repositorios y trazabilidad**
- compara snapshots y repositorios;
- identifica mejor versión por módulo;
- inventaría assets, licencias, archivos faltantes, rutas y dependencias;
- no modifica código durante auditoría.

**A2 — Especialista de exportador GDevelop**
- audita pipeline, generadores, modelo, manifiesto, adaptadores y eventos;
- corrige generación, validación, CLI, rutas y fallos silenciosos;
- entrega pruebas de contrato y reporte.

**A3 — Especialista de física y paridad**
- compara Pygame vs GDevelop;
- construye tests de trayectorias y mecánicas;
- corrige solo con pruebas de regresión;
- documenta diferencias irreducibles.

**A4 — Especialista Linux/DevEx**
- setup, scripts, dependencias, rutas, headless, Docker/devcontainer;
- no cambia gameplay ni exportador salvo adaptaciones de plataforma acordadas.

**A5 — Director de arte técnico / UI-UX**
- analiza capturas, propuestas visuales, GDD y assets;
- propone dirección visual superior y sistema de diseño;
- implementa mejoras en HUD, menús, animación y feedback;
- no cambia lógica de colisiones ni contratos de exportación.

**A6 — QA / Build / Seguridad**
- ejecuta suites, valida artefactos, rutas, recursos, consola y empaquetado;
- revisa secretos, licencias, dependencias y reproducibilidad;
- no altera gameplay para hacer pasar tests.

**A7 — Especialista de publicación GDevelop**
- investiga documentación oficial y flujo `gd.games`;
- prepara checklist y metadata;
- verifica el build y la publicación solo con sesión/permiso del usuario;
- no gestiona credenciales.

## 9.2 Paralelismo seguro

- A1 trabaja primero y en modo read-only.
- A2, A3, A4, A5 y A7 pueden investigar en paralelo después de acordar contratos.
- A2 y A3 no deben editar simultáneamente los mismos bloques/archivos. Asignar ownership de archivos o usar worktrees separados.
- A5 trabaja sobre assets/UI y propone cambios por commits aislados.
- A6 prueba cada lote y no modifica archivos de producción.
- A0 integra en orden, revisa diffs, ejecuta tests y resuelve discrepancias.
- Cada agente devuelve: resumen, archivos tocados, evidencia, comandos ejecutados, tests, riesgos, decisiones pendientes y commit/hash.
- Si un agente no puede ejecutar un test, debe decirlo; nunca reportar éxito inferido.

## 9.3 Contrato de tareas

Cada tarea debe tener:
- ID estable;
- objetivo y no-objetivos;
- archivos permitidos;
- precondiciones;
- criterios de aceptación;
- comandos de prueba;
- riesgo;
- agente responsable;
- dependencias;
- resultado y evidencia.

Usar worktrees/branches por área cuando OpenCode/Git lo permitan. No permitir que varios agentes sobrescriban el mismo working tree.

---

# 10. ESTRUCTURA DEL FORK NUEVO

Propuesta, adaptar a la estructura existente sin mover masivamente archivos si no aporta valor:

```text
in-crypta-1.0.0/
├── .opencode/
│   └── agents/
├── docs/
│   ├── architecture/
│   ├── design/
│   ├── publishing/
│   └── integration/
├── reports/
│   └── integration/
├── scripts/
│   ├── linux/
│   └── ci/
├── src/                         # solo si la migración modular lo justifica
├── tools/
│   └── exportador/
├── tests/
│   ├── unit/
│   ├── parity/
│   ├── export/
│   └── web/
├── export/
│   ├── gdevelop/                # legado aislado durante migración
│   └── gdevelop_nativo/
├── dist/                        # generado, no versionar salvo decisión explícita
├── main.py
├── config.py
├── requirements.txt
├── pyproject.toml               # si se adopta packaging moderno
├── Makefile
├── CHANGELOG.md
├── VERSION
└── README.md
```

No mover `main.py`, `config.py` ni los módulos de juego solo por estética. Priorizar integración incremental, imports estables y menor riesgo.

Crear el fork desde una rama base elegida y documentar:
- origen;
- commit base;
- fecha de integración;
- decisiones de cherry-pick;
- hashes de snapshots disponibles;
- diferencias no recuperables por archivos excluidos.

---

# 11. VERSIONADO Y CALIDAD DE RELEASE

- `VERSION` = `1.0.0`.
- `pyproject.toml` y metadata GDevelop deben coincidir cuando sea aplicable.
- SemVer: MAJOR por incompatibilidad de contrato; MINOR por funcionalidad compatible; PATCH por correcciones.
- Crear `CHANGELOG.md`.
- No etiquetar release final si hay errores críticos o tests bloqueantes.
- No llamar "1.0.0 estable" a una versión que solo compila pero no fue probada en juego real.

---

# 12. PIPELINE DE CERTIFICACIÓN OBLIGATORIO

Definir un comando único, por ejemplo:
```bash
make ci
```
o el runner equivalente existente.

Orden:
1. lint/sintaxis;
2. tests unitarios de core;
3. tests de HUD y niveles;
4. tests de física/paridad;
5. generación de proyecto nativo;
6. validación de JSON/esquema/IDs/recursos;
7. validación de eventos con metadatos de GDevelop de versión fijada;
8. validación de animaciones y máscaras;
9. verificación de paridad geométrica y gameplay;
10. build HTML5;
11. smoke test headless/navegador;
12. empaquetado;
13. checksum SHA-256 y reporte.

El modo `--check` no puede escribir. El pipeline debe trabajar en `tmp/` o staging y no contaminar fuentes.

## 12.1 Criterios mínimos de aceptación

- `python main.py` inicia en Linux con audio/display disponible.
- tests headless pasan.
- exportador genera un proyecto nativo válido.
- no hay rutas absolutas de desarrollador en el artefacto.
- todos los assets referenciados existen.
- todos los eventos son válidos para la versión objetivo.
- no hay excepciones críticas silenciadas.
- escenas y transiciones completas.
- paridad geométrica sin diferencias no justificadas.
- métricas de salto/dash dentro de tolerancias documentadas.
- build HTML5 abre sin errores críticos.
- juego jugable desde navegador.
- ZIP contiene solo los artefactos necesarios.
- instrucciones de publicación permiten obtener link en cuenta propia.
- informe final diferencia: aprobado, aprobado con limitaciones, bloqueado, requiere validación humana.

Si la vista previa del IDE o publicación no pudo verificarse, dejarlo explícito.

---

# 13. DOCUMENTACIÓN QUE DEBE QUEDAR

- `README.md`: setup y uso Linux-first.
- `docs/architecture/ARCHITECTURE.md`: capas, contratos y flujo.
- `docs/integration/DECISIONS.md`: decisiones y procedencia.
- `docs/integration/PARITY_MATRIX.md`: paridad y tolerancias.
- `docs/design/VISUAL_DIRECTION.md`: paleta, tipografía, HUD, menús y ejemplos.
- `docs/publishing/GDEVELOP_GD_GAMES.md`: publicación con fuentes oficiales y pasos vigentes.
- `docs/publishing/RELEASE_CHECKLIST.md`.
- `docs/ENTREGA_GDEVELOP.md`: estado real y link solo cuando exista.
- `reports/integration/`: inventario, auditorías, logs y evidencias.
- `CHANGELOG.md`.
- este prompt y el XML ejecutable/legible del plan.

---

# 14. FORMATO DEL INFORME FINAL

Al concluir, responder con:
1. qué base/módulos se eligieron y por qué;
2. qué se recuperó de cada proyecto;
3. qué bugs se corrigieron con evidencia;
4. qué mejoras visuales se implementaron;
5. cómo se ejecuta en Linux;
6. cómo se genera y valida GDevelop;
7. comandos exactos de pruebas y resultados reales;
8. ubicación del proyecto GDevelop y build HTML5;
9. estado de publicación `gd.games` y link real, o pasos humanos pendientes;
10. diferencias conocidas, riesgos y limitaciones;
11. commits y versión.

No decir "todo funciona" si no se probó. No inventar métricas, URLs, tests ni resultados.

---

# 15. INSTRUCCIÓN DE ARRANQUE

Comenzá en modo auditoría. No escribas código hasta:
- identificar las dos bases originales;
- generar inventario;
- determinar qué snapshot corresponde a cada línea;
- registrar estado Git;
- ejecutar baseline de tests/exportaciones que sean seguras;
- proponer matriz de selección de fuentes.

Luego presentá el plan al orquestador y ejecutá las fases del XML en orden. Si solo existen los snapshots Repomix, informá qué archivos binarios/ignorados faltan y pedí acceso a los repositorios completos antes de afirmar que el fork está construido.

**Prioridad absoluta:** una entrega real, reproducible y jugable en Linux y GDevelop, con link compartible generado por el servicio oficial; no una exportación que solo parece correcta en disco.
